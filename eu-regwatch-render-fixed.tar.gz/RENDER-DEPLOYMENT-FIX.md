# Fix for Render Dockerfile Error

## The Issue
Render is trying to use Docker deployment but can't find the Dockerfile properly. This happens when files aren't uploaded correctly or Render defaults to Docker detection.

## Solution Options

### Option 1: Force Native Node.js Deployment (Recommended)
1. **Rename the render configuration file:**
   - Delete or rename `Dockerfile` to `Dockerfile.backup`
   - Use `render-native.yaml` instead of `render.yaml`

2. **In Render Dashboard:**
   - Go to your service settings
   - Under "Build & Deploy" → "Build Command": `npm ci && npm run build`
   - Under "Build & Deploy" → "Start Command": `npm start`
   - Set Environment: `Node`

### Option 2: Fix Docker Deployment
If you want to use Docker:

1. **Ensure Dockerfile is in root directory**
2. **In Render Dashboard:**
   - Set "Build Command" to: (leave empty)
   - Set "Start Command" to: (leave empty)
   - Render will auto-detect Dockerfile

### Option 3: Manual Service Creation
1. Create a new Web Service on Render
2. **Don't use the YAML file** - configure manually:
   - Environment: `Node`
   - Build Command: `npm ci && npm run build`
   - Start Command: `npm start`
   - Auto-Deploy: Off

## Environment Variables to Set
```
NODE_ENV=production
DATABASE_URL=your_postgresql_connection_string
OPENAI_API_KEY=your_openai_key (optional)
```

## Quick Fix Steps
1. In your repository, rename `Dockerfile` to `Dockerfile.backup`
2. Rename `render-native.yaml` to `render.yaml`
3. Commit and push changes
4. Try deploying again

This will force Render to use the native Node.js buildpack instead of Docker.