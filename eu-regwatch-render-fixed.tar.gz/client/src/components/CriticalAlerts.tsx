import { useQuery } from "@tanstack/react-query";
import { AlertCircle, AlertTriangle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import type { Regulation } from "@shared/schema";

export default function CriticalAlerts() {
  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ["/api/alerts"],
    queryFn: async () => {
      const response = await fetch("/api/alerts");
      if (!response.ok) throw new Error("Failed to fetch alerts");
      return response.json() as Promise<Regulation[]>;
    }
  });

  const calculateDaysRemaining = (implementationDate: Date | null) => {
    if (!implementationDate) return null;
    const now = new Date();
    const target = new Date(implementationDate);
    const diffTime = target.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  if (isLoading) {
    return (
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-foreground mb-4">Critical Alerts</h3>
        <div className="space-y-4">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="bg-slate-800 border border-slate-700 rounded-xl p-4 animate-pulse">
              <div className="h-20"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (alerts.length === 0) {
    return (
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-foreground mb-4">Critical Alerts</h3>
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-4">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-green-500" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-green-400">No critical alerts at this time</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <h3 className="text-lg font-semibold text-foreground mb-4">Critical Alerts</h3>
      <div className="space-y-4">
        {alerts.map((alert) => {
          const daysRemaining = calculateDaysRemaining(alert.implementationDate);
          const isCritical = alert.impactLevel === "critical";
          
          return (
            <div 
              key={alert.id} 
              className={`border rounded-xl p-4 ${
                isCritical 
                  ? "bg-slate-800 border-red-500/50" 
                  : "bg-slate-800 border-orange-500/50"
              }`}
            >
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  {isCritical ? (
                    <AlertCircle className="h-5 w-5 text-red-500 mt-1" />
                  ) : (
                    <AlertTriangle className="h-5 w-5 text-orange-500 mt-1" />
                  )}
                </div>
                <div className="ml-3 flex-1">
                  <h4 className={`text-sm font-medium ${
                    isCritical ? "text-red-300" : "text-orange-300"
                  }`}>
                    {alert.title}
                  </h4>
                  <p className={`text-sm mt-1 ${
                    isCritical ? "text-red-200" : "text-orange-200"
                  }`}>
                    {alert.summary}
                  </p>
                  <div className="mt-2">
                    {daysRemaining !== null && daysRemaining > 0 ? (
                      <Badge className={
                        isCritical 
                          ? "bg-red-900 text-red-300 border-red-700" 
                          : "bg-orange-900 text-orange-300 border-orange-700"
                      }>
                        {daysRemaining} days remaining
                      </Badge>
                    ) : (
                      <Badge className={
                        isCritical 
                          ? "bg-red-900 text-red-300 border-red-700" 
                          : "bg-orange-900 text-orange-300 border-orange-700"
                      }>
                        Action required
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
