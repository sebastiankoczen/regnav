import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Timeline from "@/components/Timeline";
import StatsCards from "@/components/StatsCards";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import type { Regulation, Stats } from "@shared/schema";

export default function Analytics() {
  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
    queryFn: async () => {
      const response = await fetch("/api/stats");
      if (!response.ok) throw new Error("Failed to fetch stats");
      return response.json() as Promise<Stats>;
    }
  });

  const { data: regulations = [] } = useQuery({
    queryKey: ['/api/regulations'],
    queryFn: async () => {
      const response = await fetch('/api/regulations?limit=100&offset=0');
      if (!response.ok) throw new Error('Failed to fetch regulations');
      return response.json() as Promise<Regulation[]>;
    }
  });

  // Analytics data processing
  const impactLevelData = regulations.reduce((acc, reg) => {
    const level = reg.impactLevel || 'unknown';
    acc[level] = (acc[level] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const impactChartData = Object.entries(impactLevelData).map(([level, count]) => ({
    name: level.charAt(0).toUpperCase() + level.slice(1),
    value: count
  }));

  const industryData = regulations.reduce((acc, reg) => {
    (reg.industries || []).forEach((industry: string) => {
      acc[industry] = (acc[industry] || 0) + 1;
    });
    return acc;
  }, {} as Record<string, number>);

  const industryChartData = Object.entries(industryData)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 8)
    .map(([industry, count]) => ({
      name: industry,
      count
    }));

  const COLORS = ['#1e40af', '#dc2626', '#f59e0b', '#10b981', '#8b5cf6', '#ef4444', '#06b6d4', '#84cc16'];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Analytics Dashboard</h1>
          <p className="text-gray-600">
            Comprehensive insights into EU regulatory landscape and trends
          </p>
        </div>

        <StatsCards />

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mb-8">
          {/* Impact Level Distribution */}
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Impact Level Distribution</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={impactChartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {impactChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Top Affected Industries */}
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Most Affected Industries</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={industryChartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="name" 
                  angle={-45}
                  textAnchor="end"
                  height={80}
                  fontSize={12}
                />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#1e40af" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Implementation Timeline */}
        <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Implementation Timeline</h3>
          <Timeline />
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <h4 className="text-sm font-medium text-gray-500 mb-2">Average Preparation Time</h4>
            <p className="text-2xl font-bold text-gray-900">12 months</p>
            <p className="text-sm text-gray-600 mt-1">Based on regulation complexity</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <h4 className="text-sm font-medium text-gray-500 mb-2">Compliance Rate</h4>
            <p className="text-2xl font-bold text-eu-green">87%</p>
            <p className="text-sm text-gray-600 mt-1">Industry average</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <h4 className="text-sm font-medium text-gray-500 mb-2">Avg Implementation Cost</h4>
            <p className="text-2xl font-bold text-gray-900">€2.3M</p>
            <p className="text-sm text-gray-600 mt-1">Per major regulation</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <h4 className="text-sm font-medium text-gray-500 mb-2">Success Rate</h4>
            <p className="text-2xl font-bold text-eu-blue">94%</p>
            <p className="text-sm text-gray-600 mt-1">With proper preparation</p>
          </div>
        </div>
      </div>
    </div>
  );
}