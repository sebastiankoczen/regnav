import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Header from "@/components/Header";
import CriticalAlerts from "@/components/CriticalAlerts";
import { Calendar, Clock, AlertTriangle, Bell, BellOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Alert } from "@/lib/types";

export default function Alerts() {
  const [, setLocation] = useLocation();

  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ["/api/alerts"],
    queryFn: async () => {
      const response = await fetch("/api/alerts");
      if (!response.ok) throw new Error("Failed to fetch alerts");
      return response.json() as Promise<Alert[]>;
    }
  });

  const criticalAlerts = alerts.filter(alert => alert.impactLevel === 'critical');
  const highAlerts = alerts.filter(alert => alert.impactLevel === 'high');
  const mediumAlerts = alerts.filter(alert => alert.impactLevel === 'medium');

  const getAlertIcon = (impactLevel: string) => {
    switch (impactLevel) {
      case 'critical':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      case 'high':
        return <Clock className="h-4 w-4 text-orange-600" />;
      default:
        return <Bell className="h-4 w-4 text-blue-600" />;
    }
  };

  const getAlertBg = (impactLevel: string) => {
    switch (impactLevel) {
      case 'critical':
        return 'bg-red-50 border-red-200';
      case 'high':
        return 'bg-orange-50 border-orange-200';
      default:
        return 'bg-blue-50 border-blue-200';
    }
  };

  const formatDaysRemaining = (days?: number) => {
    if (!days) return 'No deadline';
    if (days < 0) return 'Overdue';
    if (days === 0) return 'Due today';
    if (days === 1) return '1 day remaining';
    return `${days} days remaining`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Regulation Alerts</h1>
          <p className="text-gray-600">
            Stay informed about critical deadlines and implementation requirements
          </p>
        </div>

        {/* Alert Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Critical Alerts</h3>
              <AlertTriangle className="h-5 w-5 text-red-600" />
            </div>
            <p className="text-3xl font-bold text-red-600">{criticalAlerts.length}</p>
            <p className="text-sm text-gray-600 mt-1">Immediate attention required</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">High Priority</h3>
              <Clock className="h-5 w-5 text-orange-600" />
            </div>
            <p className="text-3xl font-bold text-orange-600">{highAlerts.length}</p>
            <p className="text-sm text-gray-600 mt-1">Action needed soon</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Medium Priority</h3>
              <Bell className="h-5 w-5 text-blue-600" />
            </div>
            <p className="text-3xl font-bold text-blue-600">{mediumAlerts.length}</p>
            <p className="text-sm text-gray-600 mt-1">Plan ahead</p>
          </div>
        </div>

        {/* Critical Alerts Component */}
        <div className="mb-8">
          <CriticalAlerts />
        </div>

        {/* All Alerts */}
        <div className="bg-white rounded-xl shadow-sm border border-neutral-200">
          <div className="p-6 border-b border-neutral-200">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">All Alerts</h2>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <BellOff className="h-4 w-4 mr-2" />
                  Mark all read
                </Button>
                <Button variant="outline" size="sm">
                  <Calendar className="h-4 w-4 mr-2" />
                  Filter by date
                </Button>
              </div>
            </div>
          </div>

          <div className="divide-y divide-neutral-200">
            {isLoading ? (
              <div className="p-6">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-start space-x-4 py-4 animate-pulse">
                    <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-200 rounded mb-2 w-3/4"></div>
                      <div className="h-3 bg-gray-200 rounded mb-1 w-full"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : alerts.length === 0 ? (
              <div className="p-12 text-center">
                <Bell className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No alerts</h3>
                <p className="text-gray-600">You're all caught up! No pending alerts at this time.</p>
              </div>
            ) : (
              alerts.map((alert) => (
                <div 
                  key={alert.id} 
                  className={`p-6 hover:bg-gray-50 cursor-pointer transition-colors ${getAlertBg(alert.impactLevel)}`}
                  onClick={() => setLocation(`/regulation/${alert.id}`)}
                >
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 mt-1">
                      {getAlertIcon(alert.impactLevel)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {alert.title}
                      </h3>
                      <p className="text-gray-700 mb-3 line-clamp-2">
                        {alert.summary}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            alert.impactLevel === 'critical' ? 'bg-red-100 text-red-800' :
                            alert.impactLevel === 'high' ? 'bg-orange-100 text-orange-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {alert.impactLevel?.toUpperCase()}
                          </span>
                          {alert.implementationDate && (
                            <span className="text-sm text-gray-600">
                              Due: {new Date(alert.implementationDate).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                        <span className="text-sm font-medium text-gray-900">
                          {formatDaysRemaining(alert.daysRemaining)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}