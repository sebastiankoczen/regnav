import RegulationTimeline from '@/components/RegulationTimeline';

export default function Timeline() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <main className="flex-1">
        <div className="p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">Implementation Timeline</h1>
            <p className="text-muted-foreground">
              View upcoming EU regulation implementation dates organized by year
            </p>
          </div>
          
          <RegulationTimeline />
        </div>
      </main>
    </div>
  );
}