#!/bin/bash

# Build script for Render deployment
echo "Building EU RegWatch for production..."

# Install dependencies
echo "Installing dependencies..."
npm ci

# Build the application
echo "Building frontend and backend..."
npm run build

echo "Build completed successfully!"
echo "Ready for deployment on Render."