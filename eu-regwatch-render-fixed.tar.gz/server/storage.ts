import { 
  regulations, 
  dataSources, 
  stats,
  news,
  users,
  type Regulation, 
  type InsertRegulation,
  type DataSource,
  type InsertDataSource,
  type Stats,
  type InsertStats,
  type News,
  type InsertNews,
  type User, 
  type InsertUser 
} from "@shared/schema";

export interface IStorage {
  // Regulation methods
  getRegulations(filters?: {
    search?: string;
    industries?: string[];
    impactLevels?: string[];
    timeline?: string;
    sortBy?: string;
    limit?: number;
    offset?: number;
  }): Promise<Regulation[]>;
  getRegulation(id: number): Promise<Regulation | undefined>;
  createRegulation(regulation: InsertRegulation): Promise<Regulation>;
  updateRegulation(id: number, regulation: Partial<InsertRegulation>): Promise<Regulation | undefined>;
  deleteRegulation(id: number): Promise<boolean>;
  toggleBookmark(id: number): Promise<Regulation | undefined>;
  
  // Data source methods
  getDataSources(): Promise<DataSource[]>;
  createDataSource(dataSource: InsertDataSource): Promise<DataSource>;
  updateDataSourceStatus(id: number, status: string, lastScraped?: Date): Promise<DataSource | undefined>;
  
  // Stats methods
  getStats(): Promise<Stats | undefined>;
  updateStats(stats: InsertStats): Promise<Stats>;
  
  // News methods
  getNews(): Promise<News[]>;
  createNews(news: InsertNews): Promise<News>;
  
  // User methods (existing)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
}

export class MemStorage implements IStorage {
  private regulations: Map<number, Regulation>;
  private dataSources: Map<number, DataSource>;
  private stats: Stats | undefined;
  private news: Map<number, News>;
  private users: Map<number, User>;
  private currentRegulationId: number;
  private currentDataSourceId: number;
  private currentNewsId: number;
  private currentUserId: number;

  constructor() {
    this.regulations = new Map();
    this.dataSources = new Map();
    this.news = new Map();
    this.users = new Map();
    this.currentRegulationId = 1;
    this.currentDataSourceId = 1;
    this.currentNewsId = 1;
    this.currentUserId = 1;
    
    // Initialize default data sources and sample regulations
    this.initializeDataSources();
    this.initializeSampleRegulations();
    this.initializeStats();
    this.initializeSampleNews();
  }

  private initializeDataSources() {
    const defaultSources = [
      { name: "EUR-Lex", url: "https://eur-lex.europa.eu", status: "active" as const },
      { name: "EU Better Regulation", url: "https://ec.europa.eu/info/law/better-regulation", status: "active" as const },
      { name: "OECD", url: "https://www.oecd.org/gov/regulatory-policy", status: "active" as const },
      { name: "National Portals", url: "https://www.gesetze-im-internet.de", status: "inactive" as const },
    ];

    defaultSources.forEach(source => {
      const id = this.currentDataSourceId++;
      const dataSource: DataSource = {
        ...source,
        id,
        lastScraped: null,
        createdAt: new Date(),
      };
      this.dataSources.set(id, dataSource);
    });
  }

  private initializeSampleRegulations() {
    const sampleRegulations = [
      {
        title: "EU Deforestation Regulation (EUDR)",
        summary: "Requires due diligence to ensure products are deforestation-free. Affects cattle, cocoa, coffee, palm oil, soya, wood, rubber and derived products.",
        fullText: "Regulation (EU) 2023/1115 establishes obligations for operators placing relevant commodities on the Union market. Companies must implement due diligence systems with information, risk assessment, and mitigation measures.",
        source: "EUR-Lex",
        sourceUrl: "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32023R1115",
        impactLevel: "high" as const,
        industries: ["Food & Beverage", "Chemical Manufacturing"],
        implementationDate: new Date("2025-12-30"),
        complianceCostMin: 50000,
        complianceCostMax: 500000,
        complianceRequirements: [
          "Conduct comprehensive deforestation risk assessments",
          "Implement GPS-based supply chain monitoring",
          "Establish due diligence documentation systems",
          "Create deforestation-free sourcing protocols"
        ],
        affectedFunctions: [
          "Procurement & Sourcing",
          "Supply Chain Management",
          "Risk Management",
          "Legal & Compliance",
          "Quality Control"
        ],
        furtherReadingLinks: [
          "https://ec.europa.eu/environment/forests/deforestation.htm",
          "https://environment.ec.europa.eu/topics/forests/deforestation/regulation-deforestation-free-products_en",
          "https://single-market-economy.ec.europa.eu/sectors/raw-materials/areas-specific-interest/forest-based-industries_en"
        ],
        bestPracticeLinks: [
          "https://www.accountability-framework.org/",
          "https://www.globalforestwatch.org/",
          "https://www.trase.earth/",
          "https://www.sustainablefoodlab.org/"
        ],
        isBookmarked: false
      },
      {
        title: "Corporate Sustainability Reporting Directive (CSRD)",
        summary: "Extends sustainability reporting requirements to large companies and listed SMEs. Introduces double materiality perspective and mandatory assurance.",
        fullText: "Directive (EU) 2022/2464 requires companies to report on sustainability matters affecting their business and their impacts on people and environment according to EU sustainability reporting standards.",
        source: "EUR-Lex",
        sourceUrl: "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32022L2464",
        impactLevel: "critical" as const,
        industries: ["Financial Services", "Energy", "Pharmaceuticals", "Automotive"],
        implementationDate: new Date("2024-07-05"),
        complianceCostMin: 100000,
        complianceCostMax: 2000000,
        complianceRequirements: [
          "Implement comprehensive ESG data collection systems",
          "Establish third-party verification processes",
          "Create detailed sustainability reporting framework",
          "Ensure supply chain traceability documentation"
        ],
        affectedFunctions: [
          "Finance & Accounting",
          "Sustainability & ESG",
          "Supply Chain Management",
          "Legal & Compliance",
          "IT & Data Management"
        ],
        furtherReadingLinks: [
          "https://finance.ec.europa.eu/capital-markets-union-and-financial-markets/company-reporting-and-auditing/company-reporting/corporate-sustainability-reporting_en",
          "https://www.efrag.org/Activities/2110040929431634/European-Sustainability-Reporting-Standards",
          "https://ec.europa.eu/info/business-economy-euro/company-reporting-and-auditing/company-reporting/corporate-sustainability-reporting_en"
        ],
        bestPracticeLinks: [
          "https://www.globalreporting.org/",
          "https://www.sasb.org/",
          "https://www.tcfd.info/",
          "https://www.cdsb.net/"
        ],
        isBookmarked: true
      },
      {
        title: "Digital Product Passport (DPP)",
        summary: "Mandatory digital passports for specific product categories containing lifecycle information, materials composition, and recyclability data.",
        fullText: "Part of the Ecodesign for Sustainable Products Regulation. DPP will be accessible via QR codes/NFC tags with standardized sustainability information for batteries, textiles, and construction products.",
        source: "European Commission",
        sourceUrl: "https://ec.europa.eu/info/law/better-regulation/have-your-say/initiatives/12567-Digital-Product-Passport_en",
        impactLevel: "high" as const,
        industries: ["Automotive", "Electronics", "Textiles"],
        implementationDate: new Date("2026-02-18"),
        complianceCostMin: 25000,
        complianceCostMax: 300000,
        complianceRequirements: [
          "Install digital product tracking systems",
          "Create detailed product lifecycle documentation",
          "Establish supply chain transparency protocols",
          "Implement consumer access systems for product data"
        ],
        affectedFunctions: [
          "Product Development",
          "Supply Chain Management", 
          "Quality Assurance",
          "IT & Systems",
          "Customer Service"
        ],
        furtherReadingLinks: [
          "https://ec.europa.eu/environment/ecodesign/",
          "https://ec.europa.eu/info/law/better-regulation/have-your-say/initiatives/12567-Digital-Product-Passport_en",
          "https://single-market-economy.ec.europa.eu/industry/sustainability/circular-economy_en"
        ],
        bestPracticeLinks: [
          "https://www.circulardesign.org/",
          "https://www.ellenmacarthurfoundation.org/",
          "https://www.iso.org/standard/64472.html"
        ],
        isBookmarked: false
      },
      {
        title: "AI Act",
        summary: "Comprehensive regulation on artificial intelligence systems with risk-based approach. High-risk AI systems require conformity assessment and CE marking.",
        fullText: "Regulation (EU) 2024/1689 establishes harmonized rules for AI systems. Prohibits certain AI practices, regulates high-risk systems, and sets transparency obligations for general-purpose AI models.",
        source: "EUR-Lex",
        sourceUrl: "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32024R1689",
        impactLevel: "critical" as const,
        industries: ["Telecommunications", "Healthcare and Medical Devices", "Automotive", "Financial Services"],
        implementationDate: new Date("2025-08-02"),
        complianceCostMin: 75000,
        complianceCostMax: 1500000,
        complianceRequirements: ["Classify AI systems by risk level", "Implement quality management systems", "Conduct conformity assessments for high-risk systems"],
        affectedFunctions: ["IT", "Legal", "Product Development", "Quality Assurance"],
        furtherReadingLinks: [
          "https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai",
          "https://artificialintelligenceact.eu/",
          "https://ec.europa.eu/info/law/better-regulation/have-your-say/initiatives/12527-Artificial-intelligence-ethical-and-legal-requirements_en"
        ],
        bestPracticeLinks: [
          "https://www.iso.org/standard/77608.html",
          "https://www.ieee.org/",
          "https://www.nist.gov/itl/ai-risk-management-framework",
          "https://partnership.ai/"
        ],
        isBookmarked: false
      },
      {
        title: "Medical Device Regulation (MDR) Amendment",
        summary: "Updated requirements for medical device safety, clinical evidence, and post-market surveillance. Stricter requirements for high-risk devices.",
        fullText: "Regulation (EU) 2017/745 as amended requires enhanced clinical evidence, unique device identification, and improved transparency through EUDAMED database.",
        source: "EUR-Lex",
        sourceUrl: "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32017R0745",
        impactLevel: "critical" as const,
        industries: ["Healthcare and Medical Devices", "Pharmaceuticals"],
        implementationDate: new Date("2025-05-26"),
        complianceCostMin: 200000,
        complianceCostMax: 5000000,
        complianceRequirements: ["Update technical documentation", "Enhance post-market surveillance systems", "Implement UDI systems"],
        affectedFunctions: ["Regulatory Affairs", "Quality Assurance", "Clinical Research", "Supply Chain"],
        furtherReadingLinks: [
          "https://www.ema.europa.eu/en/human-regulatory/overview/medical-devices",
          "https://ec.europa.eu/health/md_newregulation/overview_en",
          "https://www.eudamed.eu/"
        ],
        bestPracticeLinks: [
          "https://www.iso.org/standard/59752.html",
          "https://www.fda.gov/medical-devices",
          "https://www.medtech.org/",
          "https://www.advamed.org/"
        ],
        isBookmarked: true
      },
      {
        title: "Energy Efficiency Directive Recast",
        summary: "Sets binding energy efficiency targets of 32.5% by 2030. Requires energy audits for large enterprises and energy management systems.",
        fullText: "Directive (EU) 2018/2002 establishes energy efficiency measures including mandatory energy audits, building renovation requirements, and district heating obligations.",
        source: "EUR-Lex",
        sourceUrl: "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32018L2002",
        impactLevel: "high" as const,
        industries: ["Energy", "Chemical Manufacturing", "Aerospace and Defense"],
        implementationDate: new Date("2024-12-31"),
        complianceCostMin: 30000,
        complianceCostMax: 800000,
        complianceRequirements: ["Conduct mandatory energy audits", "Implement energy management systems", "Develop energy efficiency action plans"],
        affectedFunctions: ["Facilities Management", "Operations", "Finance", "Environmental Health & Safety"],
        isBookmarked: false
      },
      {
        title: "Waste Framework Directive Amendment",
        summary: "Enhanced waste prevention and management requirements. Extended producer responsibility and circular economy measures for packaging and electronics.",
        fullText: "Directive (EU) 2018/851 amends waste management requirements with focus on waste prevention, preparation for reuse, and recycling. Sets recycling targets for municipal waste.",
        source: "EUR-Lex", 
        sourceUrl: "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32018L0851",
        impactLevel: "medium" as const,
        industries: ["Environmental Services and Waste Management", "Electronics", "Food & Beverage"],
        implementationDate: new Date("2025-01-01"),
        complianceCostMin: 40000,
        complianceCostMax: 600000,
        complianceRequirements: ["Develop waste prevention programs", "Implement extended producer responsibility schemes", "Establish separate collection systems"],
        affectedFunctions: ["Environmental Health & Safety", "Operations", "Supply Chain", "Product Development"],
        isBookmarked: false
      },
      {
        title: "REACH Regulation Update - Microplastics",
        summary: "Restricts intentionally added microplastics in products. Affects cosmetics, detergents, agricultural products, and industrial applications.",
        fullText: "Commission Regulation (EU) 2023/2055 restricts microplastics in products to reduce environmental release. Includes derogations for specific uses with transition periods.",
        source: "EUR-Lex",
        sourceUrl: "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32023R2055",
        impactLevel: "high" as const,
        industries: ["Chemical Manufacturing", "Food & Beverage", "Pharmaceuticals"],
        implementationDate: new Date("2031-10-17"),
        complianceCostMin: 60000,
        complianceCostMax: 1200000,
        complianceRequirements: ["Identify products containing microplastics", "Develop alternative formulations", "Implement labeling requirements"],
        affectedFunctions: ["R&D", "Product Development", "Regulatory Affairs", "Marketing"],
        isBookmarked: false
      },
      {
        title: "Cyber Resilience Act",
        summary: "Introduces cybersecurity requirements for products with digital elements. Mandatory CE marking and vulnerability disclosure for connected devices.",
        fullText: "Regulation (EU) 2024/2847 establishes cybersecurity requirements for hardware and software products. Includes essential requirements, conformity assessment, and market surveillance.",
        source: "European Commission",
        sourceUrl: "https://digital-strategy.ec.europa.eu/en/library/cyber-resilience-act",
        impactLevel: "critical" as const,
        industries: ["Telecommunications", "Automotive", "Healthcare and Medical Devices", "Electronics"],
        implementationDate: new Date("2027-12-11"),
        complianceCostMin: 80000,
        complianceCostMax: 2000000,
        complianceRequirements: ["Conduct cybersecurity risk assessments", "Implement secure development processes", "Establish vulnerability handling procedures"],
        affectedFunctions: ["IT Security", "Product Development", "Legal", "Quality Assurance"],
        isBookmarked: true
      },
      {
        title: "European Single Access Point (ESAP)",
        summary: "Creates central access point for corporate and financial information. Enhances transparency and data accessibility for investors and stakeholders.",
        fullText: "Regulation (EU) 2022/2554 establishes ESAP for public access to information about companies and investment products. Requires standardized data formats and reporting.",
        source: "EUR-Lex",
        sourceUrl: "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32022R2554",
        impactLevel: "medium" as const,
        industries: ["Financial Services", "Energy", "Pharmaceuticals"],
        implementationDate: new Date("2026-12-10"),
        complianceCostMin: 20000,
        complianceCostMax: 400000,
        complianceRequirements: ["Standardize financial reporting formats", "Implement digital submission systems", "Train staff on ESAP requirements"],
        affectedFunctions: ["Finance", "IT", "Legal", "Investor Relations"],
        isBookmarked: false
      }
    ];

    sampleRegulations.forEach(reg => {
      const id = this.currentRegulationId++;
      const now = new Date();
      const regulation: Regulation = {
        id,
        title: reg.title,
        summary: reg.summary,
        fullText: reg.fullText,
        source: reg.source,
        sourceUrl: reg.sourceUrl,
        impactLevel: reg.impactLevel,
        industries: reg.industries,
        implementationDate: reg.implementationDate,
        complianceCostMin: reg.complianceCostMin,
        complianceCostMax: reg.complianceCostMax,
        complianceRequirements: reg.complianceRequirements,
        affectedFunctions: reg.affectedFunctions,
        furtherReadingLinks: reg.furtherReadingLinks || [],
        bestPracticeLinks: reg.bestPracticeLinks || [],
        isBookmarked: reg.isBookmarked,
        createdAt: now,
        updatedAt: now
      };
      this.regulations.set(id, regulation);
    });
  }

  private initializeStats() {
    this.stats = {
      id: 1,
      activeCount: 0,
      criticalCount: 0,
      upcomingCount: 0,
      industriesCount: 0,
      updatedAt: new Date(),
    };
  }

  private initializeSampleNews() {
    const sampleNewsItems = [
      {
        title: "EU AI Act Compliance Deadlines Approaching for High-Risk Systems",
        summary: "Companies deploying high-risk AI systems must complete conformity assessments by August 2025. New guidance documents released by European Commission provide implementation roadmap.",
        source: "European Commission",
        sourceUrl: "https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai",
        publishedDate: new Date(),
        industries: ["Technology", "Healthcare", "Financial Services"],
        relevantRegulations: ["AI Act"],
        urgency: "high" as const
      },
      {
        title: "Corporate Sustainability Reporting Directive: First Reports Due",
        summary: "Large companies must publish their first CSRD-compliant sustainability reports covering 2024 activities. EFRAG standards now fully applicable across EU member states.",
        source: "EFRAG",
        sourceUrl: "https://www.efrag.org/",
        publishedDate: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
        industries: ["Manufacturing", "Energy", "Financial Services"],
        relevantRegulations: ["CSRD"],
        urgency: "critical" as const
      },
      {
        title: "Digital Markets Act: Commission Opens Investigation",
        summary: "The European Commission has initiated formal proceedings against tech giants for potential non-compliance with DMA gatekeeper obligations.",
        source: "European Commission",
        sourceUrl: "https://ec.europa.eu/commission/presscorner/detail/en/ip_25_2847",
        publishedDate: new Date("2025-06-01"),
        industries: ["Technology", "Digital Platforms"],
        relevantRegulations: ["Digital Markets Act"],
        urgency: "high" as const
      }
    ];

    sampleNewsItems.forEach((item) => {
      const id = ++this.currentNewsId;
      const newsItem: News = { 
        ...item, 
        id,
        createdAt: new Date()
      };
      this.news.set(id, newsItem);
    });
  }

  // Regulation methods
  async getRegulations(filters?: {
    search?: string;
    industries?: string[];
    impactLevels?: string[];
    timeline?: string;
    sortBy?: string;
    limit?: number;
    offset?: number;
  }): Promise<Regulation[]> {
    let regulationsList = Array.from(this.regulations.values());
    
    if (filters?.search) {
      const search = filters.search.toLowerCase();
      regulationsList = regulationsList.filter(reg => 
        reg.title.toLowerCase().includes(search) ||
        reg.summary.toLowerCase().includes(search)
      );
    }
    
    if (filters?.industries?.length) {
      regulationsList = regulationsList.filter(reg =>
        reg.industries.some(industry => filters.industries!.includes(industry))
      );
    }
    
    if (filters?.impactLevels?.length) {
      regulationsList = regulationsList.filter(reg =>
        filters.impactLevels!.includes(reg.impactLevel)
      );
    }
    
    if (filters?.timeline) {
      const now = new Date();
      const sixMonths = new Date(now.getTime() + 6 * 30 * 24 * 60 * 60 * 1000);
      const twelveMonths = new Date(now.getTime() + 12 * 30 * 24 * 60 * 60 * 1000);
      const twoYears = new Date(now.getTime() + 24 * 30 * 24 * 60 * 60 * 1000);
      
      regulationsList = regulationsList.filter(reg => {
        if (!reg.implementationDate) return filters.timeline === "All timelines";
        
        switch (filters.timeline) {
          case "Next 6 months":
            return reg.implementationDate <= sixMonths;
          case "6-12 months":
            return reg.implementationDate > sixMonths && reg.implementationDate <= twelveMonths;
          case "1-2 years":
            return reg.implementationDate > twelveMonths && reg.implementationDate <= twoYears;
          default:
            return true;
        }
      });
    }
    
    // Sort regulations
    if (filters?.sortBy) {
      regulationsList.sort((a, b) => {
        switch (filters.sortBy) {
          case "Implementation Date":
            return (a.implementationDate?.getTime() || 0) - (b.implementationDate?.getTime() || 0);
          case "Impact Level":
            const impactOrder = { critical: 0, high: 1, medium: 2, low: 3 };
            return impactOrder[a.impactLevel as keyof typeof impactOrder] - impactOrder[b.impactLevel as keyof typeof impactOrder];
          case "Last Updated":
            return b.updatedAt.getTime() - a.updatedAt.getTime();
          default:
            return 0;
        }
      });
    }
    
    // Apply pagination
    const offset = filters?.offset || 0;
    const limit = filters?.limit || 10;
    
    return regulationsList.slice(offset, offset + limit);
  }

  async getRegulation(id: number): Promise<Regulation | undefined> {
    return this.regulations.get(id);
  }

  async createRegulation(insertRegulation: InsertRegulation): Promise<Regulation> {
    const id = this.currentRegulationId++;
    const now = new Date();
    const regulation: Regulation = { 
      id,
      title: insertRegulation.title,
      summary: insertRegulation.summary,
      fullText: insertRegulation.fullText,
      source: insertRegulation.source,
      sourceUrl: insertRegulation.sourceUrl,
      impactLevel: insertRegulation.impactLevel,
      industries: insertRegulation.industries || [],
      implementationDate: insertRegulation.implementationDate || null,
      complianceCostMin: insertRegulation.complianceCostMin || null,
      complianceCostMax: insertRegulation.complianceCostMax || null,
      complianceRequirements: insertRegulation.complianceRequirements ?? [],
      affectedFunctions: insertRegulation.affectedFunctions ?? [],
      furtherReadingLinks: insertRegulation.furtherReadingLinks ?? [],
      bestPracticeLinks: insertRegulation.bestPracticeLinks ?? [],
      isBookmarked: insertRegulation.isBookmarked || false,
      createdAt: now,
      updatedAt: now
    };
    this.regulations.set(id, regulation);
    this.updateStatsAfterRegulationChange();
    return regulation;
  }

  async updateRegulation(id: number, updateData: Partial<InsertRegulation>): Promise<Regulation | undefined> {
    const existing = this.regulations.get(id);
    if (!existing) return undefined;
    
    const updated: Regulation = {
      ...existing,
      title: updateData.title || existing.title,
      summary: updateData.summary || existing.summary,
      fullText: updateData.fullText || existing.fullText,
      source: updateData.source || existing.source,
      sourceUrl: updateData.sourceUrl || existing.sourceUrl,
      impactLevel: updateData.impactLevel || existing.impactLevel,
      industries: updateData.industries || existing.industries,
      implementationDate: updateData.implementationDate !== undefined ? updateData.implementationDate : existing.implementationDate,
      complianceCostMin: updateData.complianceCostMin !== undefined ? updateData.complianceCostMin : existing.complianceCostMin,
      complianceCostMax: updateData.complianceCostMax !== undefined ? updateData.complianceCostMax : existing.complianceCostMax,
      complianceRequirements: updateData.complianceRequirements ?? existing.complianceRequirements,
      affectedFunctions: updateData.affectedFunctions ?? existing.affectedFunctions,
      furtherReadingLinks: updateData.furtherReadingLinks ?? existing.furtherReadingLinks,
      bestPracticeLinks: updateData.bestPracticeLinks ?? existing.bestPracticeLinks,
      isBookmarked: updateData.isBookmarked !== undefined ? updateData.isBookmarked : existing.isBookmarked,
      updatedAt: new Date()
    };
    this.regulations.set(id, updated);
    this.updateStatsAfterRegulationChange();
    return updated;
  }

  async deleteRegulation(id: number): Promise<boolean> {
    const deleted = this.regulations.delete(id);
    if (deleted) {
      this.updateStatsAfterRegulationChange();
    }
    return deleted;
  }

  async toggleBookmark(id: number): Promise<Regulation | undefined> {
    const regulation = this.regulations.get(id);
    if (!regulation) return undefined;
    
    const updated = { ...regulation, isBookmarked: !regulation.isBookmarked };
    this.regulations.set(id, updated);
    return updated;
  }

  // Data source methods
  async getDataSources(): Promise<DataSource[]> {
    return Array.from(this.dataSources.values());
  }

  async createDataSource(insertDataSource: InsertDataSource): Promise<DataSource> {
    const id = this.currentDataSourceId++;
    const dataSource: DataSource = { 
      id,
      name: insertDataSource.name,
      url: insertDataSource.url,
      status: insertDataSource.status,
      lastScraped: insertDataSource.lastScraped || null,
      createdAt: new Date()
    };
    this.dataSources.set(id, dataSource);
    return dataSource;
  }

  async updateDataSourceStatus(id: number, status: string, lastScraped?: Date): Promise<DataSource | undefined> {
    const existing = this.dataSources.get(id);
    if (!existing) return undefined;
    
    const updated: DataSource = {
      ...existing,
      status,
      lastScraped: lastScraped || new Date()
    };
    this.dataSources.set(id, updated);
    return updated;
  }

  // Stats methods
  async getStats(): Promise<Stats | undefined> {
    return this.stats;
  }

  async updateStats(newStats: InsertStats): Promise<Stats> {
    this.stats = {
      id: 1,
      activeCount: newStats.activeCount || 0,
      criticalCount: newStats.criticalCount || 0,
      upcomingCount: newStats.upcomingCount || 0,
      industriesCount: newStats.industriesCount || 0,
      updatedAt: new Date()
    };
    return this.stats;
  }

  private updateStatsAfterRegulationChange() {
    const regulations = Array.from(this.regulations.values());
    const activeCount = regulations.length;
    const criticalCount = regulations.filter(r => r.impactLevel === "critical").length;
    
    const now = new Date();
    const sixMonths = new Date(now.getTime() + 6 * 30 * 24 * 60 * 60 * 1000);
    const upcomingCount = regulations.filter(r => 
      r.implementationDate && r.implementationDate <= sixMonths
    ).length;
    
    const allIndustries = new Set();
    regulations.forEach(r => r.industries.forEach(i => allIndustries.add(i)));
    const industriesCount = allIndustries.size;
    
    this.stats = {
      id: 1,
      activeCount,
      criticalCount,
      upcomingCount,
      industriesCount,
      updatedAt: new Date()
    };
  }

  // User methods (existing)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // News methods
  async getNews(): Promise<News[]> {
    return Array.from(this.news.values()).sort((a, b) => 
      b.publishedDate.getTime() - a.publishedDate.getTime()
    );
  }

  async createNews(insertNews: InsertNews): Promise<News> {
    const id = ++this.currentNewsId;
    const newsItem: News = { 
      ...insertNews,
      id,
      industries: insertNews.industries ?? [],
      relevantRegulations: insertNews.relevantRegulations ?? [],
      urgency: insertNews.urgency ?? "medium",
      createdAt: new Date()
    };
    this.news.set(id, newsItem);
    return newsItem;
  }

  async clearNews(): Promise<void> {
    this.news.clear();
    this.currentNewsId = 1;
  }
}

export const storage = new MemStorage();
