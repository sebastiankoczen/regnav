import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { regulationScraper } from "./services/regulationScraper";
import { newsAggregator } from "./services/newsAggregator";
import { insertNewsSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all regulations with filtering
  app.get("/api/regulations", async (req, res) => {
    try {
      const regulations = await storage.getRegulations();
      res.json(regulations);
    } catch (error) {
      console.error("Error fetching regulations:", error);
      res.status(500).json({ message: "Failed to fetch regulations" });
    }
  });

  // Get single regulation
  app.get("/api/regulations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const regulation = await storage.getRegulation(id);
      
      if (!regulation) {
        return res.status(404).json({ message: "Regulation not found" });
      }
      
      res.json(regulation);
    } catch (error) {
      console.error("Error fetching regulation:", error);
      res.status(500).json({ message: "Failed to fetch regulation" });
    }
  });

  // Toggle bookmark for regulation
  app.post("/api/regulations/:id/bookmark", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const regulation = await storage.toggleBookmark(id);
      
      if (!regulation) {
        return res.status(404).json({ message: "Regulation not found" });
      }
      
      res.json(regulation);
    } catch (error) {
      console.error("Error toggling bookmark:", error);
      res.status(500).json({ message: "Failed to toggle bookmark" });
    }
  });

  // Get statistics
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getStats();
      res.json(stats || {
        activeCount: 0,
        criticalCount: 0,
        upcomingCount: 0,
        industriesCount: 0
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch statistics" });
    }
  });

  // Get data sources
  app.get("/api/data-sources", async (req, res) => {
    try {
      const sources = await storage.getDataSources();
      res.json(sources);
    } catch (error) {
      console.error("Error fetching data sources:", error);
      res.status(500).json({ message: "Failed to fetch data sources" });
    }
  });

  // Trigger manual scraping
  app.post("/api/scrape", async (req, res) => {
    try {
      // Start scraping in the background
      regulationScraper.scrapeAllSources().catch(console.error);
      res.json({ message: "Scraping started" });
    } catch (error) {
      console.error("Error starting scraping:", error);
      res.status(500).json({ message: "Failed to start scraping" });
    }
  });

  // Refresh all data (regulations and news)
  app.post("/api/refresh", async (req, res) => {
    try {
      console.log("Manual refresh triggered - updating regulations and news...");
      
      // Start both updates in parallel
      const refreshPromises = [
        regulationScraper.scrapeAllSources().catch(err => console.error("Regulation scraping error:", err)),
        newsAggregator.aggregateAllNews().catch(err => console.error("News aggregation error:", err))
      ];
      
      // Don't wait for completion, return immediately
      Promise.all(refreshPromises).then(() => {
        console.log("Data refresh completed successfully");
      }).catch(error => {
        console.error("Data refresh encountered errors:", error);
      });
      
      res.json({ 
        message: "Data refresh started successfully",
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("Error starting data refresh:", error);
      res.status(500).json({ message: "Failed to start data refresh" });
    }
  });

  // Get critical alerts (regulations with critical impact and near implementation dates)
  app.get("/api/alerts", async (req, res) => {
    try {
      const now = new Date();
      const sixMonths = new Date(now.getTime() + 6 * 30 * 24 * 60 * 60 * 1000);
      
      const criticalRegulations = await storage.getRegulations({
        impactLevels: ["critical", "high"],
        limit: 5
      });
      
      const alerts = criticalRegulations.filter(reg => {
        if (!reg.implementationDate) return false;
        return reg.implementationDate <= sixMonths;
      });
      
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  // Get timeline data
  app.get("/api/timeline", async (req, res) => {
    try {
      const regulations = await storage.getRegulations({ limit: 1000 });
      const timelineData = [];
      
      // Group by quarters
      const now = new Date();
      const quarters = [
        { name: "Q4 2024", start: new Date(2024, 9, 1), end: new Date(2024, 11, 31) },
        { name: "Q2 2025", start: new Date(2025, 3, 1), end: new Date(2025, 5, 30) },
        { name: "2026", start: new Date(2026, 0, 1), end: new Date(2026, 11, 31) },
        { name: "2027+", start: new Date(2027, 0, 1), end: new Date(2030, 11, 31) }
      ];
      
      quarters.forEach(quarter => {
        const quarterRegulations = regulations.filter(reg => {
          if (!reg.implementationDate) return false;
          return reg.implementationDate >= quarter.start && reg.implementationDate <= quarter.end;
        });
        
        timelineData.push({
          period: quarter.name,
          count: quarterRegulations.length,
          regulations: quarterRegulations.slice(0, 3).map(r => r.title)
        });
      });
      
      res.json(timelineData);
    } catch (error) {
      console.error("Error fetching timeline:", error);
      res.status(500).json({ message: "Failed to fetch timeline" });
    }
  });

  // News routes
  app.get("/api/news", async (_req, res) => {
    try {
      const news = await storage.getNews();
      res.json(news);
    } catch (error) {
      console.error("Error fetching news:", error);
      res.status(500).json({ error: "Failed to fetch news" });
    }
  });

  app.post("/api/news", async (req, res) => {
    try {
      const newsData = insertNewsSchema.parse(req.body);
      const news = await storage.createNews(newsData);
      res.status(201).json(news);
    } catch (error) {
      console.error("Error creating news:", error);
      res.status(500).json({ error: "Failed to create news" });
    }
  });

  const httpServer = createServer(app);

  // Start regulation scraping on server startup
  setTimeout(() => {
    regulationScraper.scheduleRegularScraping().catch(console.error);
  }, 1000);

  return httpServer;
}
