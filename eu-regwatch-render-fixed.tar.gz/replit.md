# EU RegWatch - EU Regulation Monitoring & Compliance Platform

## Overview

EU RegWatch is a comprehensive web application designed to monitor, track, and manage EU regulations affecting businesses. The platform provides real-time updates on regulatory changes, compliance requirements, and implementation timelines to help organizations stay compliant with evolving EU legislation.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (July 29, 2025)

- Enhanced user experience across all interface sections
- **Dashboard improvements**: Removed industry truncation - all industries now display fully without "+1" or "+2" labels
- **Regulation details upgrade**: Transformed basic overview into comprehensive executive summary with structured sections:
  - Key objectives with regulation goals and compliance framework
  - Scope and application covering affected industries and geographic reach
  - Implementation timeline with phased approach details
  - Business impact analysis including cost estimates and operational changes
- **Timeline enhancements**: Added direct source links for each regulation entry
- **News section improvements**: Made headlines clickable with direct links to news sources
- All changes maintain existing functionality while significantly improving information accessibility

### Deployment Fixes
- Fixed server port configuration to use PORT environment variable for deployment
- Updated server/index.ts to support both development (port 5000) and production environments
- Verified build process creates correct dist/index.js for deployment
- Application now properly deployable to Replit Cloud Run
- Added graceful OpenAI quota handling to prevent deployment failures
- Fixed missing News type imports in storage.ts
- Application now starts successfully with fallback analysis when OpenAI quota exceeded
- Improved production environment detection and error handling
- Made news generation non-blocking to prevent startup delays
- Fixed error handling middleware placement for proper request processing

### Render Deployment Ready (August 6, 2025)
- Created comprehensive Render deployment configuration with render.yaml
- Added Dockerfile and .dockerignore for containerized deployment
- Built deployment scripts (build.sh and start.sh) for automated setup
- Generated detailed deployment guide (README-RENDER-DEPLOYMENT.md)
- Created optimized deployment package (eu-regwatch-render-deployment.tar.gz)
- Configured for Node.js 18+ with PostgreSQL database support
- Ready for one-click deployment on Render with environment variables setup

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Framework**: Shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom dark theme configuration
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management

### Backend Architecture
- **Runtime**: Node.js with Express.js REST API
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured for Neon serverless)
- **Session Management**: PostgreSQL-based session storage

### Key Components

#### Database Schema
- **Regulations Table**: Core entity storing regulation details, impact levels, industries, compliance requirements
- **Data Sources Table**: Tracks external regulatory data sources and their scraping status
- **Stats Table**: Aggregated statistics for dashboard metrics
- **News Table**: Regulatory news and updates from various sources
- **Users Table**: User management (planned for future authentication)

#### API Services
- **Regulation Scraper**: Automated data collection from EU sources (EUR-Lex, Better Regulation portal)
- **News Aggregator**: Collects regulatory news from consultations and national registers
- **Fresh News Generator**: Daily automated news updates with current regulatory developments
- **OpenAI Service**: AI-powered regulation analysis for impact assessment and compliance guidance

#### Frontend Components
- **Dashboard**: Clean overview with regulations table (news and timeline moved to separate pages)
- **Regulations Table**: Searchable, sortable table displaying all regulations
- **Timeline Page**: Visual implementation timeline showing regulation dates by year
- **News History Page**: Complete regulatory news feed with unlimited display
- **Header Navigation**: Simple navigation between Dashboard, Timeline, and News pages
- **Regulation Detail**: Comprehensive view of individual regulations
- **Analytics**: Charts and visualizations for regulation trends
- **Alerts**: Critical compliance deadlines and notifications

## Data Flow

1. **Data Collection**: Automated scrapers collect regulation data from EU sources
2. **AI Analysis**: OpenAI service analyzes regulations for impact assessment
3. **Data Storage**: Processed data stored in PostgreSQL via Drizzle ORM
4. **API Layer**: Express.js serves data through RESTful endpoints
5. **Frontend Display**: React components consume API data via TanStack Query
6. **User Interaction**: Users can bookmark, filter, and search regulations

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Server state management
- **axios**: HTTP client for external API calls
- **cheerio**: HTML parsing for web scraping
- **wouter**: Lightweight routing

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Dependencies
- **vite**: Build tool and dev server
- **typescript**: Type safety
- **tsx**: TypeScript execution
- **esbuild**: Fast bundling for production

## Deployment Strategy

### Development Environment
- Vite dev server for frontend hot reloading
- tsx for backend TypeScript execution
- Replit integration with runtime error overlay

### Production Build
- Vite builds optimized frontend bundle to `dist/public`
- esbuild bundles backend to `dist/index.js`
- Single Node.js process serves both API and static files

### Database Management
- Drizzle Kit for schema migrations
- Environment-based database URL configuration
- PostgreSQL session store for scalability

### External Service Integration
- OpenAI API for regulation analysis
- EU regulatory websites for data scraping
- Configurable data source monitoring

The application follows a modern full-stack architecture with clear separation between frontend and backend, type safety throughout, and scalable data management for regulatory compliance monitoring.