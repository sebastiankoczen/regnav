# EU RegWatch - Render Deployment Guide

## Overview
This guide explains how to deploy the EU RegWatch regulatory monitoring platform on Render.

## Prerequisites
1. A Render account (render.com)
2. A PostgreSQL database (can be created on Render or use external provider like Neon)
3. OpenAI API key (optional - app works with fallback data if not provided)

## Deployment Steps

### Option 1: Using GitHub Repository (Recommended)
1. Push your code to a GitHub repository
2. Connect the repository to Render
3. Render will automatically detect the `render.yaml` file and configure the service

### Option 2: Manual Deployment
1. Create a new Web Service on Render
2. Configure the following settings:
   - **Environment**: Node
   - **Build Command**: `npm ci && npm run build`
   - **Start Command**: `npm start`
   - **Node Version**: 18 (automatically detected from package.json engines)

## Environment Variables
Set these environment variables in your Render dashboard:

### Required
- `DATABASE_URL`: PostgreSQL connection string
- `NODE_ENV`: Set to `production`

### Optional  
- `OPENAI_API_KEY`: Your OpenAI API key for enhanced regulation analysis
- `PORT`: Automatically set by Render (don't override)

## Database Setup

### Option 1: Render PostgreSQL (Recommended)
1. Create a PostgreSQL database on Render
2. Copy the connection string to `DATABASE_URL`

### Option 2: External Database (Neon, etc.)
1. Create a PostgreSQL database on your preferred provider
2. Set the connection string as `DATABASE_URL`

## Post-Deployment
1. The app will automatically run database migrations on startup
2. Initial regulation data will be populated
3. News aggregation will begin running automatically
4. Access your app at the provided Render URL

## Features Available
- ✅ Real-time regulation monitoring
- ✅ News aggregation from EU sources  
- ✅ Interactive dashboard with filtering
- ✅ Timeline visualization
- ✅ Manual refresh functionality
- ✅ Responsive design for mobile/desktop

## Troubleshooting

### Build Issues
- Ensure all dependencies are listed in package.json
- Check that Node.js version is compatible (18+)

### Database Issues  
- Verify DATABASE_URL is correctly formatted
- Ensure database allows connections from Render's IP ranges

### Performance
- Render free tier has some limitations
- Consider upgrading to paid plan for production use

## Support
For deployment issues, check:
1. Render build logs
2. Application logs in Render dashboard
3. Database connection status