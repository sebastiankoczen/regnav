#!/bin/bash

# Production start script for Render
echo "Starting EU RegWatch in production mode..."

# Set environment
export NODE_ENV=production

# Start the application
node dist/index.js