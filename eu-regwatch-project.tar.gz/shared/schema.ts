import { pgTable, serial, text, timestamp, boolean, integer, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const regulations = pgTable("regulations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  fullText: text("full_text").notNull(),
  source: text("source").notNull(),
  sourceUrl: text("source_url").notNull(),
  impactLevel: text("impact_level").notNull(), // "critical", "high", "medium", "low"
  industries: text("industries").array().notNull(),
  implementationDate: timestamp("implementation_date"),
  complianceCostMin: integer("compliance_cost_min"),
  complianceCostMax: integer("compliance_cost_max"),
  complianceRequirements: json("compliance_requirements").$type<string[]>().notNull(),
  affectedFunctions: json("affected_functions").$type<string[]>().notNull(),
  furtherReadingLinks: json("further_reading_links").$type<string[]>().notNull().default([]),
  bestPracticeLinks: json("best_practice_links").$type<string[]>().notNull().default([]),
  isBookmarked: boolean("is_bookmarked").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const dataSources = pgTable("data_sources", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  url: text("url").notNull(),
  status: text("status").notNull(), // "active", "inactive", "error"
  lastScraped: timestamp("last_scraped"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const stats = pgTable("stats", {
  id: serial("id").primaryKey(),
  activeCount: integer("active_count").notNull().default(0),
  criticalCount: integer("critical_count").notNull().default(0),
  upcomingCount: integer("upcoming_count").notNull().default(0),
  industriesCount: integer("industries_count").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  summary: text("summary").notNull(),
  source: text("source").notNull(),
  sourceUrl: text("source_url").notNull(),
  publishedDate: timestamp("published_date").notNull(),
  industries: text("industries").array().notNull().default([]),
  relevantRegulations: text("relevant_regulations").array().notNull().default([]),
  urgency: text("urgency").notNull().default("medium"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertRegulationSchema = createInsertSchema(regulations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertDataSourceSchema = createInsertSchema(dataSources).omit({
  id: true,
  createdAt: true,
});

export const insertStatsSchema = createInsertSchema(stats).omit({
  id: true,
  updatedAt: true,
});

export const insertNewsSchema = createInsertSchema(news).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertRegulation = z.infer<typeof insertRegulationSchema>;
export type Regulation = typeof regulations.$inferSelect;
export type InsertDataSource = z.infer<typeof insertDataSourceSchema>;
export type DataSource = typeof dataSources.$inferSelect;
export type InsertStats = z.infer<typeof insertStatsSchema>;
export type Stats = typeof stats.$inferSelect;
export type InsertNews = z.infer<typeof insertNewsSchema>;
export type News = typeof news.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;