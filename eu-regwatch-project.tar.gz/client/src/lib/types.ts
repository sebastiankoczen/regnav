export interface FilterState {
  search: string;
  industries: string[];
  impactLevels: string[];
  timeline: string;
  sortBy: string;
}

export interface TimelineItem {
  period: string;
  count: number;
  regulations: string[];
}

export interface Alert {
  id: number;
  title: string;
  summary: string;
  impactLevel: string;
  implementationDate: Date | null;
  daysRemaining?: number;
}
