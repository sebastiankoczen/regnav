import { useQuery } from "@tanstack/react-query";
import { Calendar, Clock, AlertCircle, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getQueryFn } from "@/lib/queryClient";
import type { Regulation } from "@shared/schema";

export default function RegulationTimeline() {
  const { data: regulations = [], isLoading } = useQuery({
    queryKey: ['/api/regulations'],
    queryFn: getQueryFn({ on401: 'throw' })
  }) as { data: Regulation[], isLoading: boolean };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Implementation Timeline
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-muted rounded" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Group regulations by year
  const regulationsByYear = regulations.reduce((acc: Record<number, Regulation[]>, regulation: Regulation) => {
    const year = regulation.implementationDate ? new Date(regulation.implementationDate).getFullYear() : new Date().getFullYear();
    if (!acc[year]) {
      acc[year] = [];
    }
    acc[year].push(regulation);
    return acc;
  }, {} as Record<number, Regulation[]>);

  // Sort years
  const sortedYears = Object.keys(regulationsByYear)
    .map(Number)
    .sort((a, b) => a - b);

  const getImpactColor = (level: string) => {
    switch (level) {
      case 'critical':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      case 'high':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      default:
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Implementation Timeline
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Upcoming regulation implementation dates by year
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {sortedYears.map((year) => (
            <div key={year} className="relative">
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center justify-center w-8 h-8 bg-primary text-primary-foreground rounded-full text-sm font-semibold">
                  {String(year).slice(-2)}
                </div>
                <h3 className="text-lg font-semibold text-foreground">{year}</h3>
                <Badge variant="outline" className="ml-auto">
                  {regulationsByYear[year].length} regulation{regulationsByYear[year].length !== 1 ? 's' : ''}
                </Badge>
              </div>
              
              <div className="ml-5 pl-6 border-l-2 border-muted space-y-3">
                {regulationsByYear[year]
                  .sort((a: Regulation, b: Regulation) => {
                    const dateA = a.implementationDate ? new Date(a.implementationDate).getTime() : 0;
                    const dateB = b.implementationDate ? new Date(b.implementationDate).getTime() : 0;
                    return dateA - dateB;
                  })
                  .map((regulation: Regulation) => (
                    <div
                      key={regulation.id}
                      className="relative bg-card border rounded-lg p-4 hover:shadow-md transition-shadow"
                    >
                      <div className="absolute -left-[25px] top-4 w-3 h-3 bg-primary rounded-full border-2 border-background" />
                      
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-medium text-foreground leading-tight pr-2">
                          {regulation.title}
                        </h4>
                        <Badge className={getImpactColor(regulation.impactLevel)}>
                          {regulation.impactLevel}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {regulation.implementationDate ? formatDate(regulation.implementationDate.toString()) : 'TBD'}
                        </div>
                        <div className="flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          {regulation.source}
                        </div>
                        {regulation.sourceUrl && (
                          <a 
                            href={regulation.sourceUrl} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-blue-400 hover:text-blue-300 transition-colors"
                          >
                            <ExternalLink className="w-3 h-3" />
                            View Source
                          </a>
                        )}
                      </div>
                      
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {regulation.summary}
                      </p>
                      
                      {regulation.industries.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-3">
                          {regulation.industries.map((industry: string) => (
                            <Badge key={industry} variant="secondary" className="text-xs">
                              {industry}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}