import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArrowUpDown, ArrowUp, ArrowDown, ExternalLink, Eye, Filter } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { getQueryFn } from "@/lib/queryClient";
import type { Regulation } from "@shared/schema";

type SortField = 'title' | 'industries' | 'source' | 'impactLevel' | 'implementationDate';
type SortOrder = 'asc' | 'desc';

interface ColumnFilters {
  industry: string;
  source: string;
  impactLevel: string;
}

export default function RegulationsTable() {
  const [sortField, setSortField] = useState<SortField>('implementationDate');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [searchTerm, setSearchTerm] = useState('');
  const [columnFilters, setColumnFilters] = useState<ColumnFilters>({
    industry: '',
    source: '',
    impactLevel: ''
  });

  const { data: regulations = [], isLoading } = useQuery({
    queryKey: ['/api/regulations'],
    queryFn: getQueryFn({ on401: 'throw' })
  }) as { data: Regulation[], isLoading: boolean };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  // Get unique values for filter dropdowns
  const filterOptions = useMemo(() => {
    if (!Array.isArray(regulations)) return { industries: [], sources: [], impactLevels: [] };
    
    const allIndustries = new Set<string>();
    const allSources = new Set<string>();
    const allImpactLevels = new Set<string>();
    
    regulations.forEach((reg: Regulation) => {
      reg.industries.forEach((industry: string) => allIndustries.add(industry));
      allSources.add(reg.source);
      allImpactLevels.add(reg.impactLevel);
    });
    
    return {
      industries: Array.from(allIndustries).sort(),
      sources: Array.from(allSources).sort(),
      impactLevels: Array.from(allImpactLevels).sort()
    };
  }, [regulations]);

  // Clear all filters
  const clearAllFilters = () => {
    setSearchTerm('');
    setColumnFilters({
      industry: '',
      source: '',
      impactLevel: ''
    });
  };

  // Filter and sort regulations
  const filteredAndSortedRegulations = useMemo(() => {
    if (!Array.isArray(regulations)) return [];
    let filtered = regulations;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter((reg: Regulation) => 
        reg.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        reg.source.toLowerCase().includes(searchTerm.toLowerCase()) ||
        reg.industries.some((industry: string) => 
          industry.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
    }

    // Apply column filters
    if (columnFilters.industry) {
      filtered = filtered.filter((reg: Regulation) => 
        reg.industries.includes(columnFilters.industry)
      );
    }

    if (columnFilters.source) {
      filtered = filtered.filter((reg: Regulation) => 
        reg.source === columnFilters.source
      );
    }

    if (columnFilters.impactLevel) {
      filtered = filtered.filter((reg: Regulation) => 
        reg.impactLevel === columnFilters.impactLevel
      );
    }

    // Sort regulations
    const sorted = [...filtered].sort((a: Regulation, b: Regulation) => {
      let aValue: any;
      let bValue: any;

      switch (sortField) {
        case 'title':
          aValue = a.title.toLowerCase();
          bValue = b.title.toLowerCase();
          break;
        case 'industries':
          aValue = a.industries.join(', ').toLowerCase();
          bValue = b.industries.join(', ').toLowerCase();
          break;
        case 'source':
          aValue = a.source.toLowerCase();
          bValue = b.source.toLowerCase();
          break;
        case 'impactLevel':
          const impactOrder = { 'critical': 4, 'high': 3, 'medium': 2, 'low': 1 };
          aValue = impactOrder[a.impactLevel as keyof typeof impactOrder] || 0;
          bValue = impactOrder[b.impactLevel as keyof typeof impactOrder] || 0;
          break;
        case 'implementationDate':
          aValue = a.implementationDate ? new Date(a.implementationDate).getTime() : 0;
          bValue = b.implementationDate ? new Date(b.implementationDate).getTime() : 0;
          break;
        default:
          return 0;
      }

      if (sortField === 'impactLevel' || sortField === 'implementationDate') {
        return sortOrder === 'asc' ? aValue - bValue : bValue - aValue;
      } else {
        const result = String(aValue).localeCompare(String(bValue));
        return sortOrder === 'asc' ? result : -result;
      }
    });

    return sorted;
  }, [regulations, searchTerm, sortField, sortOrder, columnFilters]);

  const getStatusBadge = (regulation: Regulation) => {
    if (!regulation.implementationDate) {
      return <Badge className="bg-gray-600 text-gray-300">TBD</Badge>;
    }
    
    const now = new Date();
    const implementationDate = new Date(regulation.implementationDate);
    const daysUntil = Math.ceil((implementationDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntil < 0) {
      return <Badge className="bg-blue-600 text-blue-100">Active</Badge>;
    } else if (daysUntil <= 90) {
      return <Badge className="bg-red-600 text-red-100">Imminent</Badge>;
    } else {
      return <Badge className="bg-yellow-600 text-yellow-100">Upcoming</Badge>;
    }
  };

  const getImpactLevelColor = (level: string) => {
    switch (level) {
      case "critical":
        return "bg-red-600 text-red-100";
      case "high":
        return "bg-orange-600 text-orange-100";
      case "medium":
        return "bg-yellow-600 text-yellow-100";
      case "low":
        return "bg-green-600 text-green-100";
      default:
        return "bg-gray-600 text-gray-100";
    }
  };

  const formatDate = (date: Date | null) => {
    if (!date) return "TBD";
    return new Date(date).toLocaleDateString("en-GB", {
      year: "numeric",
      month: "short",
      day: "numeric"
    });
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) {
      return <ArrowUpDown className="h-4 w-4 text-slate-400" />;
    }
    return sortOrder === 'asc' 
      ? <ArrowUp className="h-4 w-4 text-blue-400" />
      : <ArrowDown className="h-4 w-4 text-blue-400" />;
  };

  if (isLoading) {
    return (
      <Card className="bg-card border-border">
        <CardContent className="text-center py-8">
          <div className="text-muted-foreground">Loading regulations...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader className="space-y-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-card-foreground">Active Regulations</CardTitle>
          <div className="w-72">
            <Input
              placeholder="Search regulations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-input border-border text-foreground"
            />
          </div>
        </div>
        
        {/* Column Filters */}
        <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg border border-border">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground font-medium">Filters:</span>
          </div>
          
          <div className="flex items-center gap-4 flex-1">
            <div className="flex flex-col gap-1">
              <label className="text-xs text-muted-foreground">Industry</label>
              <Select 
                value={columnFilters.industry} 
                onValueChange={(value) => setColumnFilters(prev => ({ ...prev, industry: value === 'all' ? '' : value }))}
              >
                <SelectTrigger className="w-40 h-8 bg-background border-border">
                  <SelectValue placeholder="All Industries" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Industries</SelectItem>
                  {filterOptions.industries.map((industry) => (
                    <SelectItem key={industry} value={industry}>{industry}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex flex-col gap-1">
              <label className="text-xs text-muted-foreground">Source</label>
              <Select 
                value={columnFilters.source} 
                onValueChange={(value) => setColumnFilters(prev => ({ ...prev, source: value === 'all' ? '' : value }))}
              >
                <SelectTrigger className="w-40 h-8 bg-background border-border">
                  <SelectValue placeholder="All Sources" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sources</SelectItem>
                  {filterOptions.sources.map((source) => (
                    <SelectItem key={source} value={source}>{source}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex flex-col gap-1">
              <label className="text-xs text-muted-foreground">Impact Level</label>
              <Select 
                value={columnFilters.impactLevel} 
                onValueChange={(value) => setColumnFilters(prev => ({ ...prev, impactLevel: value === 'all' ? '' : value }))}
              >
                <SelectTrigger className="w-32 h-8 bg-background border-border">
                  <SelectValue placeholder="All Levels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  {filterOptions.impactLevels.map((level) => (
                    <SelectItem key={level} value={level}>
                      {level.charAt(0).toUpperCase() + level.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={clearAllFilters}
            className="text-muted-foreground hover:text-foreground"
          >
            Clear All
          </Button>
        </div>
        
        {/* Active filters indicator */}
        {(searchTerm || columnFilters.industry || columnFilters.source || columnFilters.impactLevel) && (
          <div className="text-sm text-muted-foreground">
            Showing {filteredAndSortedRegulations.length} of {regulations.length} regulations
          </div>
        )}
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-muted/50">
              <TableHead className="text-muted-foreground">
                <Button 
                  variant="ghost" 
                  className="h-auto p-0 font-medium text-muted-foreground hover:text-foreground"
                  onClick={() => handleSort('industries')}
                >
                  Industry
                  <SortIcon field="industries" />
                </Button>
              </TableHead>
              <TableHead className="text-muted-foreground">
                <Button 
                  variant="ghost" 
                  className="h-auto p-0 font-medium text-muted-foreground hover:text-foreground"
                  onClick={() => handleSort('title')}
                >
                  Regulation
                  <SortIcon field="title" />
                </Button>
              </TableHead>
              <TableHead className="text-muted-foreground">
                <Button 
                  variant="ghost" 
                  className="h-auto p-0 font-medium text-muted-foreground hover:text-foreground"
                  onClick={() => handleSort('source')}
                >
                  Source
                  <SortIcon field="source" />
                </Button>
              </TableHead>
              <TableHead className="text-muted-foreground">Status</TableHead>
              <TableHead className="text-muted-foreground">
                <Button 
                  variant="ghost" 
                  className="h-auto p-0 font-medium text-muted-foreground hover:text-foreground"
                  onClick={() => handleSort('impactLevel')}
                >
                  Impact
                  <SortIcon field="impactLevel" />
                </Button>
              </TableHead>
              <TableHead className="text-muted-foreground">
                <Button 
                  variant="ghost" 
                  className="h-auto p-0 font-medium text-muted-foreground hover:text-foreground"
                  onClick={() => handleSort('implementationDate')}
                >
                  Implementation
                  <SortIcon field="implementationDate" />
                </Button>
              </TableHead>
              <TableHead className="text-muted-foreground">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredAndSortedRegulations.map((regulation) => (
              <TableRow key={regulation.id} className="border-border hover:bg-muted/50">
                <TableCell className="text-muted-foreground">
                  <div className="flex flex-wrap gap-1">
                    {regulation.industries.map((industry: string) => (
                      <Badge key={industry} variant="outline" className="text-xs">
                        {industry}
                      </Badge>
                    ))}
                  </div>
                </TableCell>
                <TableCell className="text-foreground font-medium min-w-80">
                  <div className="line-clamp-2" title={regulation.title}>
                    {regulation.title}
                  </div>
                </TableCell>
                <TableCell className="text-muted-foreground">{regulation.source}</TableCell>
                <TableCell>{getStatusBadge(regulation)}</TableCell>
                <TableCell>
                  <Badge className={getImpactLevelColor(regulation.impactLevel)}>
                    {regulation.impactLevel}
                  </Badge>
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {formatDate(regulation.implementationDate)}
                </TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Link href={`/regulation/${regulation.id}`}>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </Link>
                    {regulation.sourceUrl && (
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0" asChild>
                        <a href={regulation.sourceUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}