import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Bookmark, CheckCircle, Circle } from "lucide-react";
import { Link } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import type { Regulation } from "@shared/schema";

interface RegulationCardProps {
  regulation: Regulation;
}

export default function RegulationCard({ regulation }: RegulationCardProps) {
  const queryClient = useQueryClient();

  const bookmarkMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/regulations/${regulation.id}/bookmark`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/regulations"] });
    }
  });

  const getImpactLevelColor = (level: string) => {
    switch (level) {
      case "critical":
        return "bg-red-100 text-red-800";
      case "high":
        return "bg-orange-100 text-orange-800";
      case "medium":
        return "bg-yellow-100 text-yellow-800";
      case "low":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getIndustryColor = (industry: string) => {
    const colors = [
      "bg-blue-100 text-blue-800",
      "bg-purple-100 text-purple-800",
      "bg-green-100 text-green-800",
      "bg-pink-100 text-pink-800",
      "bg-indigo-100 text-indigo-800"
    ];
    return colors[industry.length % colors.length];
  };

  const formatCurrency = (min?: number | null, max?: number | null) => {
    if (!min && !max) return "Cost assessment pending";
    if (min && max) return `€${min.toLocaleString()} - €${max.toLocaleString()}`;
    if (min) return `From €${min.toLocaleString()}`;
    if (max) return `Up to €${max.toLocaleString()}`;
    return "Cost assessment pending";
  };

  const formatDate = (date: Date | null) => {
    if (!date) return "TBD";
    return new Date(date).toLocaleDateString("en-GB", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center flex-wrap gap-3 mb-2">
            <h4 className="text-lg font-medium text-gray-900">{regulation.title}</h4>
            <Badge className={getImpactLevelColor(regulation.impactLevel)}>
              {regulation.impactLevel} Impact
            </Badge>
            {regulation.industries.map((industry) => (
              <Badge key={industry} className={getIndustryColor(industry)}>
                {industry}
              </Badge>
            ))}
          </div>
          
          <p className="text-gray-600 mb-3">{regulation.summary}</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <span className="text-xs text-gray-500 uppercase tracking-wide">Implementation</span>
              <p className="text-sm font-medium text-gray-900">
                {formatDate(regulation.implementationDate)}
              </p>
            </div>
            <div>
              <span className="text-xs text-gray-500 uppercase tracking-wide">Source</span>
              <p className="text-sm font-medium text-gray-900">{regulation.source}</p>
            </div>
            <div>
              <span className="text-xs text-gray-500 uppercase tracking-wide">Est. Compliance Cost</span>
              <p className="text-sm font-medium text-gray-900">
                {formatCurrency(regulation.complianceCostMin, regulation.complianceCostMax)}
              </p>
            </div>
          </div>

          {regulation.complianceRequirements.length > 0 && (
            <div className="border-t border-neutral-200 pt-4">
              <h5 className="text-sm font-medium text-gray-900 mb-2">Key Requirements:</h5>
              <ul className="text-sm text-gray-600 space-y-1">
                {regulation.complianceRequirements.slice(0, 3).map((requirement, index) => (
                  <li key={index} className="flex items-center">
                    {index === 0 ? (
                      <CheckCircle className="h-3 w-3 text-eu-green mr-2 flex-shrink-0" />
                    ) : (
                      <Circle className="h-3 w-3 text-gray-300 mr-2 flex-shrink-0" />
                    )}
                    {requirement}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
        
        <div className="ml-6 flex flex-col items-end space-y-2">
          <Link href={`/regulation/${regulation.id}`}>
            <Button variant="link" className="text-eu-blue hover:text-blue-700 text-sm p-0">
              View Details
            </Button>
          </Link>
          <Button
            variant="ghost"
            size="sm"
            className="p-1"
            onClick={() => bookmarkMutation.mutate()}
            disabled={bookmarkMutation.isPending}
          >
            <Bookmark 
              className={`h-4 w-4 ${regulation.isBookmarked ? 'fill-current text-eu-blue' : 'text-gray-400'}`} 
            />
          </Button>
        </div>
      </div>
    </div>
  );
}
