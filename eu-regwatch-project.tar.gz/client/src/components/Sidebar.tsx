import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import type { FilterState } from "@/lib/types";
import type { DataSource } from "@shared/schema";

interface SidebarProps {
  filters: FilterState;
  onFiltersChange: (filters: Partial<FilterState>) => void;
}

export default function Sidebar({ filters, onFiltersChange }: SidebarProps) {
  const { data: dataSources = [] } = useQuery({
    queryKey: ["/api/data-sources"],
    queryFn: async () => {
      const response = await fetch("/api/data-sources");
      if (!response.ok) throw new Error("Failed to fetch data sources");
      return response.json() as Promise<DataSource[]>;
    }
  });

  const handleIndustryChange = (industry: string) => {
    const newIndustries = filters.industries.includes(industry)
      ? filters.industries.filter(i => i !== industry)
      : [...filters.industries, industry];
    onFiltersChange({ industries: newIndustries });
  };

  const handleImpactLevelChange = (level: string) => {
    const newLevels = filters.impactLevels.includes(level)
      ? filters.impactLevels.filter(l => l !== level)
      : [...filters.impactLevels, level];
    onFiltersChange({ impactLevels: newLevels });
  };

  const getStatusIndicator = (status: string) => {
    switch (status) {
      case "active":
        return <div className="w-2 h-2 bg-eu-green rounded-full"></div>;
      case "inactive":
        return <div className="w-2 h-2 bg-yellow-400 rounded-full"></div>;
      default:
        return <div className="w-2 h-2 bg-red-500 rounded-full"></div>;
    }
  };

  return (
    <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 lg:pt-16 bg-white dark:bg-gray-900 border-r border-neutral-200 dark:border-gray-700">
      <div className="flex-1 flex flex-col min-h-0 overflow-y-auto">
        <div className="p-4 bg-white dark:bg-gray-900">
          <h2 className="text-sm font-semibold text-gray-900 dark:text-gray-100 uppercase tracking-wide mb-4">Filters</h2>
          
          {/* Industry Filter */}
          <div className="mb-6">
            <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Industry Sector</Label>
            <Select
              value={filters.industries[0] || ""}
              onValueChange={(value) => value && handleIndustryChange(value)}
            >
              <SelectTrigger className="w-full bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-gray-100">
                <SelectValue placeholder="All Sectors" />
              </SelectTrigger>
              <SelectContent className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 text-gray-900 dark:text-gray-100">
                <SelectItem value="Pharmaceuticals" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Pharmaceuticals</SelectItem>
                <SelectItem value="Financial Services" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Financial Services</SelectItem>
                <SelectItem value="Energy" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Energy (oil, gas, renewables)</SelectItem>
                <SelectItem value="Automotive" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Automotive</SelectItem>
                <SelectItem value="Aerospace and Defense" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Aerospace and Defense</SelectItem>
                <SelectItem value="Chemical Manufacturing" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Chemical Manufacturing</SelectItem>
                <SelectItem value="Food & Beverage" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Food & Beverage</SelectItem>
                <SelectItem value="Telecommunications" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Telecommunications</SelectItem>
                <SelectItem value="Healthcare and Medical Devices" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Healthcare and Medical Devices</SelectItem>
                <SelectItem value="Environmental Services and Waste Management" className="text-gray-900 dark:text-gray-100 hover:bg-gray-100 dark:hover:bg-gray-700">Environmental Services and Waste Management</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Impact Level Filter */}
          <div className="mb-6">
            <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Impact Level</Label>
            <div className="space-y-2">
              {[
                { value: "critical", label: "Critical", color: "bg-red-500" },
                { value: "high", label: "High", color: "bg-eu-amber" },
                { value: "medium", label: "Medium", color: "bg-yellow-400" },
                { value: "low", label: "Low", color: "bg-eu-green" }
              ].map(({ value, label, color }) => (
                <div key={value} className="flex items-center space-x-2">
                  <Checkbox
                    id={value}
                    checked={filters.impactLevels.includes(value)}
                    onCheckedChange={() => handleImpactLevelChange(value)}
                    className="border-gray-300 dark:border-gray-600 data-[state=checked]:bg-blue-600 dark:data-[state=checked]:bg-blue-500"
                  />
                  <Label htmlFor={value} className="text-sm flex-1 text-gray-700 dark:text-gray-300">{label}</Label>
                  <div className={`w-2 h-2 ${color} rounded-full`}></div>
                </div>
              ))}
            </div>
          </div>

          {/* Timeline Filter */}
          <div className="mb-6">
            <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Implementation Timeline</Label>
            <RadioGroup 
              value={filters.timeline} 
              onValueChange={(value) => onFiltersChange({ timeline: value })}
            >
              {[
                "Next 6 months",
                "6-12 months", 
                "1-2 years",
                "All timelines"
              ].map((timeline) => (
                <div key={timeline} className="flex items-center space-x-2">
                  <RadioGroupItem value={timeline} id={timeline} className="border-gray-300 dark:border-gray-600 text-blue-600 dark:text-blue-400" />
                  <Label htmlFor={timeline} className="text-sm text-gray-700 dark:text-gray-300">{timeline}</Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {/* Data Sources */}
          <div className="mb-6">
            <Label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Data Sources</Label>
            <div className="space-y-2 text-xs">
              {dataSources.map((source) => (
                <div key={source.id} className="flex items-center justify-between">
                  <span className="text-gray-700 dark:text-gray-300">{source.name}</span>
                  {getStatusIndicator(source.status)}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
