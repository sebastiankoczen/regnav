import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { BarChart3, Calendar, Newspaper, Home, RefreshCw } from "lucide-react";
import { useState } from "react";
import { queryClient } from "@/lib/queryClient";

export default function Header() {
  const [location] = useLocation();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const navItems = [
    { path: "/", label: "Dashboard", icon: Home },
    { path: "/timeline", label: "Timeline", icon: Calendar },
    { path: "/news", label: "News", icon: Newspaper },
  ];

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      const response = await fetch('/api/refresh', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        // Invalidate all cached data to trigger refetch
        queryClient.invalidateQueries();
        
        // Show success feedback briefly
        setTimeout(() => {
          setIsRefreshing(false);
        }, 2000);
      } else {
        setIsRefreshing(false);
        console.error('Refresh failed');
      }
    } catch (error) {
      setIsRefreshing(false);
      console.error('Refresh error:', error);
    }
  };

  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center px-6">
        <div className="mr-8">
          <h1 className="text-xl font-bold">EU Regulatory Intelligence</h1>
        </div>
        
        <nav className="flex items-center space-x-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <Link key={item.path} href={item.path}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <Icon className="w-4 h-4" />
                  {item.label}
                </Button>
              </Link>
            );
          })}
        </nav>
        
        <div className="ml-auto">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            {isRefreshing ? 'Refreshing...' : 'Refresh Data'}
          </Button>
        </div>
      </div>
    </header>
  );
}