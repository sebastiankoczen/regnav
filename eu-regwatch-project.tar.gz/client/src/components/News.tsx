import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Calendar, Building2, AlertTriangle, Clock } from "lucide-react";
import type { News } from "../../../shared/schema";



export default function News() {
  const { data: newsItems = [], isLoading } = useQuery<News[]>({
    queryKey: ['/api/news']
  });

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "high":
        return "bg-red-900 text-red-300 border-red-700";
      case "medium":
        return "bg-orange-900 text-orange-300 border-orange-700";
      case "low":
        return "bg-green-900 text-green-300 border-green-700";
      default:
        return "bg-slate-700 text-slate-300 border-slate-600";
    }
  };

  if (isLoading) {
    return (
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-foreground mb-6">Latest Regulatory News</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-3">
                <div className="h-4 bg-slate-700 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-slate-700 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-slate-700 rounded"></div>
                  <div className="h-3 bg-slate-700 rounded w-5/6"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mb-8 bg-transparent dark:bg-transparent">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-foreground dark:text-white">Latest Regulatory News</h2>
        <p className="text-sm text-slate-400 dark:text-gray-300">
          Daily updates from EU consultation pages, national registers, and sector publications
        </p>
      </div>

      <div className="space-y-3">
        {newsItems?.map((item) => (
          <Card key={item.id} className="hover:shadow-lg transition-shadow bg-gray-800 dark:bg-gray-800 border border-gray-700 dark:border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Badge className={`${getUrgencyColor(item.urgency)} border text-xs`}>
                    <AlertTriangle className="w-3 h-3 mr-1" />
                    {item.urgency.toUpperCase()}
                  </Badge>
                  <div className="flex items-center text-xs text-muted-foreground dark:text-gray-300">
                    <Clock className="w-3 h-3 mr-1" />
                    {formatDate(item.publishedDate)}
                  </div>
                </div>
                <div className="flex items-center text-xs text-muted-foreground dark:text-gray-300">
                  <ExternalLink className="w-3 h-3 mr-1" />
                  <span className="font-medium">{item.source}</span>
                </div>
              </div>
              
              <h3 className="text-base font-semibold leading-tight mb-2 text-foreground dark:text-white">
                {item.title}
              </h3>
              
              <p className="text-sm text-muted-foreground dark:text-gray-300 mb-3 line-clamp-2">
                {item.summary}
              </p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  {item.industries.length > 0 && (
                    <div className="flex items-center gap-1">
                      <Building2 className="w-3 h-3 text-muted-foreground dark:text-gray-300" />
                      <div className="flex gap-1">
                        {item.industries.slice(0, 2).map((industry) => (
                          <Badge key={industry} variant="secondary" className="text-xs px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
                            {industry}
                          </Badge>
                        ))}
                        {item.industries.length > 2 && (
                          <Badge variant="secondary" className="text-xs px-2 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
                            +{item.industries.length - 2}
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {item.relevantRegulations.length > 0 && (
                    <div className="flex gap-1">
                      {item.relevantRegulations.slice(0, 1).map((regulation) => (
                        <Badge key={regulation} variant="outline" className="text-xs px-2 py-0.5 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300">
                          {regulation}
                        </Badge>
                      ))}
                      {item.relevantRegulations.length > 1 && (
                        <Badge variant="outline" className="text-xs px-2 py-0.5 border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300">
                          +{item.relevantRegulations.length - 1}
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
                
                <a
                  href={item.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-primary dark:text-primary hover:underline flex items-center"
                >
                  Read more
                  <ExternalLink className="w-3 h-3 ml-1" />
                </a>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {newsItems.length === 0 && (
        <Card className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700">
          <CardContent className="text-center py-8">
            <p className="text-slate-400 dark:text-gray-300">
              No news items available. News updates require real-time data access from regulatory sources.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}