import { useQuery } from "@tanstack/react-query";
import type { TimelineItem } from "@/lib/types";

export default function Timeline() {
  const { data: timelineData = [], isLoading } = useQuery({
    queryKey: ["/api/timeline"],
    queryFn: async () => {
      const response = await fetch("/api/timeline");
      if (!response.ok) throw new Error("Failed to fetch timeline");
      return response.json() as Promise<TimelineItem[]>;
    }
  });

  const getTimelineColor = (period: string) => {
    if (period.includes("2024")) return "bg-red-500";
    if (period.includes("2025")) return "bg-eu-amber";
    if (period.includes("2026")) return "bg-yellow-400";
    return "bg-eu-green";
  };

  if (isLoading) {
    return (
      <div className="mb-8">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Implementation Timeline</h3>
        <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6 animate-pulse">
          <div className="space-y-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-start">
                <div className="w-4 h-4 bg-gray-200 rounded-full mt-1"></div>
                <div className="ml-4 flex-1">
                  <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Implementation Timeline</h3>
      <div className="bg-white rounded-xl shadow-sm border border-neutral-200 p-6">
        <div className="space-y-6">
          {timelineData.map((item, index) => (
            <div key={index} className="flex items-start">
              <div className={`flex-shrink-0 w-4 h-4 ${getTimelineColor(item.period)} rounded-full mt-1`}></div>
              <div className="ml-4 flex-1">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-medium text-gray-900">{item.period}</h4>
                  <span className="text-xs text-gray-500">{item.count} regulations</span>
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  {item.regulations.length > 0 
                    ? item.regulations.join(", ")
                    : "No regulations scheduled for this period"
                  }
                  {item.regulations.length >= 3 && item.count > 3 && 
                    ` and ${item.count - 3} more...`
                  }
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
