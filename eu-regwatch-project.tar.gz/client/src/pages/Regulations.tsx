import RegulationsTable from '@/components/RegulationsTable';

export default function Regulations() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <main className="flex-1">
        <div className="p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">All Regulations</h1>
            <p className="text-muted-foreground">
              Comprehensive database of EU regulations with search functionality
            </p>
          </div>
          
          <RegulationsTable />
        </div>
      </main>
    </div>
  );
}