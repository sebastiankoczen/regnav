import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, ExternalLink, Bookmark, CheckCircle, AlertTriangle, Clock, Building2, Building } from "lucide-react";
import { Link, useRoute } from "wouter";
import type { Regulation } from "@shared/schema";

export default function RegulationDetail() {
  const [match, params] = useRoute("/regulation/:id");
  const regulationId = params?.id;

  const { data: regulation, isLoading } = useQuery({
    queryKey: ["/api/regulations", regulationId],
    queryFn: async () => {
      const response = await fetch(`/api/regulations/${regulationId}`);
      if (!response.ok) throw new Error("Failed to fetch regulation");
      return response.json() as Promise<Regulation>;
    },
    enabled: !!regulationId
  });

  const getImpactLevelColor = (level: string) => {
    switch (level) {
      case "critical":
        return "bg-red-900 text-red-300 border-red-700";
      case "high":
        return "bg-orange-900 text-orange-300 border-orange-700";
      case "medium":
        return "bg-yellow-900 text-yellow-300 border-yellow-700";
      case "low":
        return "bg-green-900 text-green-300 border-green-700";
      default:
        return "bg-slate-700 text-slate-300 border-slate-600";
    }
  };

  const formatDate = (date: Date | null) => {
    if (!date) return "TBD";
    return new Date(date).toLocaleDateString("en-GB", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  };

  const formatCurrency = (min?: number | null, max?: number | null) => {
    if (!min && !max) return "Cost assessment pending";
    if (min && max) return `€${min.toLocaleString()} - €${max.toLocaleString()}`;
    if (min) return `From €${min.toLocaleString()}`;
    if (max) return `Up to €${max.toLocaleString()}`;
    return "Cost assessment pending";
  };

  const getComplianceRequirements = (regulation: Regulation) => {
    return regulation.complianceRequirements || [];
  };

  const getAffectedFunctions = (regulation: Regulation) => {
    return regulation.affectedFunctions || [];
  };

  const getBestPractices = (regulation: Regulation) => {
    const practices = [
      {
        category: "Early Preparation",
        items: [
          "Establish a cross-functional compliance team",
          "Conduct gap analysis against current practices",
          "Create implementation timeline with milestones",
          "Allocate dedicated budget for compliance activities"
        ]
      },
      {
        category: "Documentation & Processes",
        items: [
          "Document all compliance procedures",
          "Implement version control for regulatory documents",
          "Create audit trails for all compliance activities",
          "Establish regular review cycles"
        ]
      },
      {
        category: "Training & Awareness",
        items: [
          "Train relevant staff on new requirements",
          "Create awareness campaigns across organization",
          "Establish competency assessments",
          "Maintain training records"
        ]
      },
      {
        category: "Technology & Systems",
        items: [
          "Assess IT system capabilities",
          "Implement necessary system upgrades",
          "Ensure data integration across platforms",
          "Establish monitoring and reporting systems"
        ]
      }
    ];

    return practices;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-700 rounded w-1/4 mb-6"></div>
            <div className="h-12 bg-slate-700 rounded w-3/4 mb-4"></div>
            <div className="h-6 bg-slate-700 rounded w-full mb-8"></div>
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-32 bg-slate-700 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!regulation) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-4xl mx-auto text-center py-16">
          <h2 className="text-2xl font-semibold text-foreground mb-4">Regulation Not Found</h2>
          <p className="text-muted-foreground mb-8">The requested regulation could not be found.</p>
          <Link href="/">
            <Button>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const bestPractices = getBestPractices(regulation);

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto p-4 sm:p-6 lg:p-8">
        {/* Header */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
          </Link>
          
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-foreground mb-2">{regulation.title}</h1>
              <div className="flex flex-wrap gap-2 mb-4">
                <Badge className={`${getImpactLevelColor(regulation.impactLevel)} border`}>
                  {regulation.impactLevel} Impact
                </Badge>
                {regulation.industries.map((industry) => (
                  <Badge key={industry} variant="outline" className="bg-slate-700 text-slate-300 border-slate-600">
                    {industry}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm">
                <Bookmark className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" asChild>
                <a href={regulation.sourceUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  View Source
                </a>
              </Button>
            </div>
          </div>
          
          <p className="text-lg text-slate-300 leading-relaxed">{regulation.summary}</p>
        </div>

        {/* Key Information Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
                <Clock className="mr-2 h-4 w-4" />
                Implementation Date
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-semibold text-foreground">{formatDate(regulation.implementationDate)}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400 flex items-center">
                <Building2 className="mr-2 h-4 w-4" />
                Source
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-semibold text-foreground">{regulation.source}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-400 flex items-center">
                <AlertTriangle className="mr-2 h-4 w-4" />
                Est. Compliance Cost
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg font-semibold text-foreground">
                {formatCurrency(regulation.complianceCostMin, regulation.complianceCostMax)}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Executive Summary */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Executive Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Key Objectives */}
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center">
                  <CheckCircle className="h-5 w-5 text-eu-green mr-2" />
                  Key Objectives
                </h3>
                <div className="prose max-w-none text-slate-300 leading-relaxed bg-slate-800 p-4 rounded-lg">
                  <p className="mb-3">
                    <strong>Primary Goal:</strong> {regulation.summary}
                  </p>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Establish comprehensive regulatory framework for enhanced compliance</li>
                    <li>Standardize reporting requirements across EU member states</li>
                    <li>Improve transparency and accountability in affected industries</li>
                    <li>Align with broader EU sustainability and digital transformation goals</li>
                  </ul>
                </div>
              </div>

              {/* Scope and Application */}
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center">
                  <Building2 className="h-5 w-5 text-eu-blue mr-2" />
                  Scope and Application
                </h3>
                <div className="prose max-w-none text-slate-300 leading-relaxed bg-slate-800 p-4 rounded-lg">
                  <p className="mb-3">
                    <strong>Industries Affected:</strong> {regulation.industries.join(', ')}
                  </p>
                  <p className="mb-3">
                    This regulation applies to organizations operating within the European Union, 
                    particularly those engaged in cross-border activities, manufacturing, and service provision. 
                    The regulation establishes new standards that will impact business operations, 
                    reporting requirements, and compliance procedures.
                  </p>
                  <p>
                    <strong>Geographic Scope:</strong> All EU Member States, with provisions for third-country cooperation.
                  </p>
                </div>
              </div>

              {/* Implementation Timeline */}
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center">
                  <Clock className="h-5 w-5 text-yellow-500 mr-2" />
                  Implementation Timeline
                </h3>
                <div className="prose max-w-none text-slate-300 leading-relaxed bg-slate-800 p-4 rounded-lg">
                  <p className="mb-3">
                    <strong>Full Implementation Date:</strong> {formatDate(regulation.implementationDate)}
                  </p>
                  <div className="space-y-2">
                    <p><strong>Phase 1:</strong> Initial compliance framework establishment (6 months prior)</p>
                    <p><strong>Phase 2:</strong> Reporting system deployment (3 months prior)</p>
                    <p><strong>Phase 3:</strong> Full operational compliance (implementation date)</p>
                    <p><strong>Phase 4:</strong> Ongoing monitoring and enforcement (post-implementation)</p>
                  </div>
                </div>
              </div>

              {/* Business Impact Analysis */}
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-3 flex items-center">
                  <AlertTriangle className="h-5 w-5 text-orange-500 mr-2" />
                  Business Impact Analysis
                </h3>
                <div className="prose max-w-none text-slate-300 leading-relaxed bg-slate-800 p-4 rounded-lg">
                  <p className="mb-3">
                    <strong>Impact Level:</strong> <span className="text-red-400 font-semibold">{regulation.impactLevel.toUpperCase()}</span>
                  </p>
                  <p className="mb-3">
                    <strong>Estimated Compliance Cost:</strong> {formatCurrency(regulation.complianceCostMin, regulation.complianceCostMax)}
                  </p>
                  <div className="space-y-2">
                    <p><strong>Operational Changes:</strong> Organizations will need to implement new processes, systems, and reporting mechanisms.</p>
                    <p><strong>Resource Requirements:</strong> Additional personnel, technology infrastructure, and ongoing training programs.</p>
                    <p><strong>Risk Mitigation:</strong> Early preparation and phased implementation approach recommended to minimize disruption.</p>
                  </div>
                </div>
              </div>

              {/* Detailed Regulation Text */}
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  Full Regulation Details
                </h3>
                <div className="prose max-w-none text-slate-300 leading-relaxed bg-slate-900 p-4 rounded-lg">
                  {regulation.fullText.split('\n').map((paragraph, index) => (
                    <p key={index} className="mb-4">{paragraph}</p>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Compliance Requirements */}
        {getComplianceRequirements(regulation).length > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckCircle className="h-5 w-5 text-eu-green mr-2" />
                Key Compliance Requirements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {getComplianceRequirements(regulation).map((requirement, index) => (
                  <div key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-eu-green mr-3 mt-0.5 flex-shrink-0" />
                    <p className="text-foreground">{requirement}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Affected Company Functions */}
        {getAffectedFunctions(regulation).length > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building2 className="h-5 w-5 text-eu-blue mr-2" />
                Affected Company Functions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {getAffectedFunctions(regulation).map((func, index) => (
                  <div key={index} className="flex items-center p-3 bg-secondary rounded-lg">
                    <div className="w-2 h-2 bg-eu-blue rounded-full mr-3"></div>
                    <span className="text-foreground font-medium">{func}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* External Resources */}
        {(regulation.furtherReadingLinks?.length > 0 || regulation.bestPracticeLinks?.length > 0) && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {regulation.furtherReadingLinks?.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Further Reading</CardTitle>
                  <p className="text-sm text-slate-400">
                    Official resources and comprehensive guides
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {regulation.furtherReadingLinks.map((link, index) => (
                      <a
                        key={index}
                        href={link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-sm text-eu-blue hover:text-blue-700 hover:underline"
                      >
                        <ExternalLink className="h-4 w-4 mr-2 flex-shrink-0" />
                        {new URL(link).hostname}
                      </a>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {regulation.bestPracticeLinks?.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Best Practice Resources</CardTitle>
                  <p className="text-sm text-slate-400">
                    Industry guidelines and implementation tools
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {regulation.bestPracticeLinks.map((link, index) => (
                      <a
                        key={index}
                        href={link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center text-sm text-blue-400 hover:text-blue-300 hover:underline"
                      >
                        <ExternalLink className="h-4 w-4 mr-2 flex-shrink-0" />
                        {new URL(link).hostname}
                      </a>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Best Practices */}
        <Card>
          <CardHeader>
            <CardTitle>Implementation Best Practices</CardTitle>
            <p className="text-sm text-slate-400">
              Proven strategies for successful compliance implementation based on industry experience
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {bestPractices.map((category) => (
                <div key={category.category}>
                  <h4 className="font-semibold text-foreground mb-3">{category.category}</h4>
                  <ul className="space-y-2">
                    {category.items.map((item, index) => (
                      <li key={index} className="flex items-start text-sm text-slate-300">
                        <div className="w-2 h-2 bg-eu-blue rounded-full mr-3 mt-2 flex-shrink-0"></div>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}