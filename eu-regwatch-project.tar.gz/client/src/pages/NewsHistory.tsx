import { useQuery } from "@tanstack/react-query";
import { Clock, ExternalLink, AlertTriangle, Filter } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getQueryFn } from "@/lib/queryClient";
import { useState, useMemo } from "react";

interface NewsItem {
  id: number;
  title: string;
  summary: string;
  source: string;
  sourceUrl: string;
  publishedDate: string;
  industries: string[];
  relevantRegulations: string[];
  urgency: 'high' | 'medium' | 'low' | 'critical';
}

export default function NewsHistory() {
  const [selectedIndustry, setSelectedIndustry] = useState<string>("all");
  
  const { data: newsItems = [], isLoading } = useQuery({
    queryKey: ['/api/news'],
    queryFn: getQueryFn({ on401: 'throw' })
  }) as { data: NewsItem[], isLoading: boolean };
  
  // Get unique industries for filtering
  const availableIndustries = useMemo(() => {
    const industries = new Set<string>();
    newsItems.forEach(item => {
      item.industries.forEach(industry => industries.add(industry));
    });
    return Array.from(industries).sort();
  }, [newsItems]);
  
  // Filter news by selected industry
  const filteredNews = useMemo(() => {
    if (selectedIndustry === "all") return newsItems;
    return newsItems.filter(item => 
      item.industries.includes(selectedIndustry)
    );
  }, [newsItems, selectedIndustry]);

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'critical':
        return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
      case 'high':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      default:
        return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      if (diffInDays === 1) {
        return 'Yesterday';
      } else if (diffInDays < 7) {
        return `${diffInDays} days ago`;
      } else {
        return date.toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
        });
      }
    }
  };

  if (isLoading) {
    return (
      <div className="bg-background text-foreground min-h-screen">
        <main className="flex-1">
          <div className="p-6">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-foreground mb-2">Regulatory News</h1>
              <p className="text-muted-foreground">Latest regulatory developments and updates</p>
            </div>
            <div className="animate-pulse space-y-4">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-32 bg-muted rounded-lg" />
              ))}
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="bg-background text-foreground min-h-screen">
      <main className="flex-1">
        <div className="p-6">
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">Regulatory News</h1>
                <p className="text-muted-foreground">
                  Real-time updates from EU Commission, EUR-Lex, and regulatory news sources
                </p>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-muted-foreground" />
                  <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Filter by industry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Industries</SelectItem>
                      {availableIndustries.map((industry) => (
                        <SelectItem key={industry} value={industry}>
                          {industry}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Badge variant="outline" className="text-sm">
                  {filteredNews.length} article{filteredNews.length !== 1 ? 's' : ''}
                </Badge>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {filteredNews.map((item) => (
              <Card key={item.id} className="hover:shadow-lg transition-shadow bg-gray-800 dark:bg-gray-800 border border-gray-700 dark:border-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <Badge className={`${getUrgencyColor(item.urgency)} border text-xs font-medium`}>
                        <AlertTriangle className="w-3 h-3 mr-1" />
                        {item.urgency.toUpperCase()}
                      </Badge>
                      <div className="flex items-center text-sm text-muted-foreground dark:text-gray-300">
                        <Clock className="w-4 h-4 mr-1" />
                        {formatDate(item.publishedDate)}
                      </div>
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground dark:text-gray-300">
                      <ExternalLink className="w-4 h-4 mr-1" />
                      <span className="font-medium">{item.source}</span>
                    </div>
                  </div>
                  
                  <a 
                    href={item.sourceUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="block hover:bg-slate-700 p-2 -m-2 rounded transition-colors"
                  >
                    <h3 className="text-xl font-semibold leading-tight mb-3 text-foreground dark:text-white hover:text-blue-400 transition-colors cursor-pointer flex items-center">
                      {item.title}
                      <ExternalLink className="w-4 h-4 ml-2 opacity-60" />
                    </h3>
                  </a>
                  
                  <p className="text-muted-foreground dark:text-gray-300 mb-4 leading-relaxed">
                    {item.summary}
                  </p>
                  
                  <div className="flex flex-wrap gap-2 mb-3">
                    <div className="text-sm text-muted-foreground dark:text-gray-400">
                      <span className="font-medium">Industries:</span>
                    </div>
                    {item.industries.map((industry) => (
                      <Badge key={industry} variant="secondary" className="text-xs">
                        {industry}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    <div className="text-sm text-muted-foreground dark:text-gray-400">
                      <span className="font-medium">Related Regulations:</span>
                    </div>
                    {item.relevantRegulations.map((regulation) => (
                      <Badge key={regulation} variant="outline" className="text-xs">
                        {regulation}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}