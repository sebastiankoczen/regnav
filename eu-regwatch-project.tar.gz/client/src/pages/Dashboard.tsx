import StatsCards from '@/components/StatsCards';
import RegulationsTable from '@/components/RegulationsTable';

export default function Dashboard() {
  return (
    <div className="bg-background text-foreground min-h-screen">
      <main className="flex-1">
        <div className="p-6 space-y-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">EU Regulatory Dashboard</h1>
            <p className="text-muted-foreground">
              Monitor and track EU regulations affecting your business
            </p>
          </div>
          
          <StatsCards />
          
          <div className="w-full">
            <RegulationsTable />
          </div>
        </div>
      </main>
    </div>
  );
}