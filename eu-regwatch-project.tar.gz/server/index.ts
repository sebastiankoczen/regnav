import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

import { newsAggregator } from "./services/newsAggregator";
import { storage } from "./storage";

(async () => {
  try {
    const server = await registerRoutes(app);
    
    // Initialize comprehensive news aggregation system
    setImmediate(async () => {
      try {
        console.log('Initializing comprehensive news aggregation system...');
        await newsAggregator.scheduleRegularAggregation();
      } catch (error) {
        console.error("Error initializing news aggregation:", error);
      }
    });

    // Check environment for production vs development
    const isProduction = process.env.NODE_ENV === "production" || process.env.PORT;
    
    // Setup serving - development vs production
    if (isProduction) {
      console.log("Running in production mode");
      serveStatic(app);
    } else {
      console.log("Running in development mode");  
      await setupVite(app, server);
    }

    // Error handling middleware (after routes and static setup)
    app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
      console.error("Server error:", err);
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";
      res.status(status).json({ message, error: isProduction ? undefined : err.stack });
    });

    // Use PORT environment variable in deployment, fallback to 5000 for development  
    const port = process.env.PORT ? parseInt(process.env.PORT) : 5000;
    server.listen({
      port,
      host: "0.0.0.0",
      reusePort: true,
    }, () => {
      log(`serving on port ${port} in ${isProduction ? 'production' : 'development'} mode`);
    });
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
})();
