import axios from 'axios';
import * as cheerio from 'cheerio';
import { openaiService } from './openaiService';
import { storage } from '../storage';
import type { InsertRegulation } from '@shared/schema';

interface ScrapedRegulation {
  title: string;
  fullText: string;
  sourceUrl: string;
  source: string;
}

export class RegulationScraper {
  private async scrapeEurLex(): Promise<ScrapedRegulation[]> {
    try {
      // EU Deforestation Regulation example
      const mockRegulations: ScrapedRegulation[] = [
        {
          title: "EU Deforestation Regulation (EUDR)",
          fullText: `Regulation (EU) 2023/1115 on the making available on the Union market and the export from the Union of certain commodities and products associated with deforestation and forest degradation. This regulation establishes obligations for operators and traders who place, make available or export from the Union market cattle, cocoa, coffee, palm oil, soya, wood, rubber, and derived products. The regulation requires due diligence to ensure that relevant products are deforestation-free and have been produced in accordance with the relevant legislation of the country of production. Operators must implement due diligence systems that contain information, risk assessment procedures, and risk mitigation measures. The regulation applies to all operators and traders regardless of their size.`,
          sourceUrl: "https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32023R1115",
          source: "EUR-Lex"
        }
      ];

      return mockRegulations;
    } catch (error) {
      console.error('Error scraping EUR-Lex:', error);
      return [];
    }
  }

  private async scrapeBetterRegulation(): Promise<ScrapedRegulation[]> {
    try {
      // Corporate Sustainability Reporting Directive example
      const mockRegulations: ScrapedRegulation[] = [
        {
          title: "Corporate Sustainability Reporting Directive (CSRD)",
          fullText: `Directive (EU) 2022/2464 amending Regulation (EU) No 537/2014, Directive 2004/109/EC, Directive 2006/43/EC and Directive 2013/34/EU, as regards corporate sustainability reporting. The directive extends the scope of sustainability reporting requirements to cover large companies and small and medium-sized companies listed on regulated markets. Companies must report on how sustainability issues affect their business, and on their impacts on people and the environment. The sustainability information must be reported according to EU sustainability reporting standards and be subject to assurance. The directive introduces the 'double materiality' perspective, meaning companies must report on sustainability matters that are material to their business and on how their business impacts society and the environment.`,
          sourceUrl: "https://ec.europa.eu/info/law/better-regulation/have-your-say/initiatives/12129-Corporate-sustainability-reporting-revision-of-Directive-2013-34-EU_en",
          source: "EU Better Regulation"
        }
      ];

      return mockRegulations;
    } catch (error) {
      console.error('Error scraping EU Better Regulation:', error);
      return [];
    }
  }

  private async scrapeOECD(): Promise<ScrapedRegulation[]> {
    try {
      // Digital Product Passport example
      const mockRegulations: ScrapedRegulation[] = [
        {
          title: "Digital Product Passport (DPP)",
          fullText: `The Digital Product Passport is part of the Ecodesign for Sustainable Products Regulation proposal. It will provide comprehensive information about products throughout their lifecycle, including materials composition, repairability, and recyclability data. The DPP will be accessible via QR codes or NFC tags and will contain standardized sustainability information. This initiative aims to support the transition to a circular economy by making product information transparent and accessible to consumers, manufacturers, and recyclers. The passport will be mandatory for specific product categories, starting with batteries, textiles, and construction products.`,
          sourceUrl: "https://www.oecd.org/gov/regulatory-policy/digital-product-passport.htm",
          source: "OECD"
        }
      ];

      return mockRegulations;
    } catch (error) {
      console.error('Error scraping OECD:', error);
      return [];
    }
  }

  async scrapeAllSources(): Promise<void> {
    console.log('Starting regulation scraping from all sources...');
    
    try {
      // Update data source statuses to indicate scraping has started
      const sources = await storage.getDataSources();
      for (const source of sources) {
        await storage.updateDataSourceStatus(source.id, 'active');
      }

      // Scrape from all sources
      const [eurLexRegulations, betterRegulations, oecdRegulations] = await Promise.all([
        this.scrapeEurLex(),
        this.scrapeBetterRegulation(),
        this.scrapeOECD()
      ]);

      const allRegulations = [
        ...eurLexRegulations,
        ...betterRegulations,
        ...oecdRegulations
      ];

      // Process each regulation with AI
      for (const scrapedReg of allRegulations) {
        try {
          const aiAnalysis = await openaiService.analyzeRegulation(scrapedReg.fullText);
          
          const regulation: InsertRegulation = {
            title: scrapedReg.title,
            summary: aiAnalysis.summary,
            fullText: scrapedReg.fullText,
            source: scrapedReg.source,
            sourceUrl: scrapedReg.sourceUrl,
            impactLevel: aiAnalysis.impactLevel,
            industries: aiAnalysis.affectedIndustries,
            implementationDate: aiAnalysis.implementationDate ? new Date(aiAnalysis.implementationDate) : null,
            complianceCostMin: aiAnalysis.estimatedCost?.min,
            complianceCostMax: aiAnalysis.estimatedCost?.max,
            preparationSteps: aiAnalysis.preparationSteps,
            isBookmarked: false
          };

          await storage.createRegulation(regulation);
          console.log(`Created regulation: ${regulation.title}`);
        } catch (error) {
          console.error(`Error processing regulation ${scrapedReg.title}:`, error);
        }
      }

      console.log(`Successfully processed ${allRegulations.length} regulations`);
    } catch (error) {
      console.error('Error in scrapeAllSources:', error);
    }
  }

  async scheduleRegularScraping(): Promise<void> {
    // Initial scrape
    await this.scrapeAllSources();
    
    // Schedule regular scraping every 24 hours
    setInterval(async () => {
      console.log('Running scheduled regulation scraping...');
      await this.scrapeAllSources();
    }, 24 * 60 * 60 * 1000); // 24 hours
  }
}

export const regulationScraper = new RegulationScraper();
