import OpenAI from "openai";

interface RegulationAnalysis {
  summary: string;
  impactLevel: "critical" | "high" | "medium" | "low";
  affectedIndustries: string[];
  implementationDate?: string;
  estimatedCost?: {
    min: number;
    max: number;
  };
  preparationSteps: string[];
}

class OpenAIService {
  private openai: OpenAI;

  constructor() {
    this.openai = new OpenAI({ 
      apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
    });
  }

  async analyzeRegulation(regulationText: string): Promise<RegulationAnalysis> {
    try {
      // Check if OpenAI API key is available
      if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "default_key") {
        console.log("OpenAI API key not configured, using fallback analysis");
        return this.getFallbackAnalysis();
      }

      const prompt = `
        Analyze the following EU regulation text and provide a comprehensive analysis focused on manufacturing impact. 
        Please respond with JSON in this exact format:
        {
          "summary": "A concise 2-3 sentence summary focusing on manufacturing implications",
          "impactLevel": "critical|high|medium|low",
          "affectedIndustries": ["industry1", "industry2", ...],
          "implementationDate": "YYYY-MM-DD or null",
          "estimatedCost": {"min": number, "max": number} or null,
          "preparationSteps": ["step1", "step2", "step3"]
        }

        Consider these manufacturing industries: Automotive, Electronics, Pharmaceuticals, Food & Beverage, Textiles, Chemical, Construction, Machinery, Aerospace, Medical Devices.

        Impact levels:
        - critical: Immediate compliance required, high penalties, fundamental business changes
        - high: Significant operational changes, substantial costs, near-term deadlines
        - medium: Moderate changes required, manageable costs, reasonable timeline
        - low: Minor adjustments, low cost impact, distant deadlines

        Regulation text:
        ${regulationText}
      `;

      const response = await this.openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: "You are an expert regulatory analyst specializing in EU manufacturing regulations. Provide accurate, actionable analysis for manufacturers."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      
      // Validate and sanitize the response
      return {
        summary: result.summary || "Analysis unavailable",
        impactLevel: ["critical", "high", "medium", "low"].includes(result.impactLevel) ? result.impactLevel : "medium",
        affectedIndustries: Array.isArray(result.affectedIndustries) ? result.affectedIndustries : [],
        implementationDate: result.implementationDate || undefined,
        estimatedCost: result.estimatedCost && typeof result.estimatedCost === 'object' ? result.estimatedCost : undefined,
        preparationSteps: Array.isArray(result.preparationSteps) ? result.preparationSteps : []
      };
    } catch (error: any) {
      console.error("Error analyzing regulation with OpenAI:", error);
      
      // Check if it's a quota/rate limit error
      if (error?.status === 429 || error?.code === 'insufficient_quota') {
        console.log("OpenAI quota exceeded, using fallback analysis");
      }
      
      return this.getFallbackAnalysis();
    }
  }

  async summarizeComplexText(text: string): Promise<string> {
    try {
      // Check if OpenAI API key is available  
      if (!process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY === "default_key") {
        return "Summary unavailable - OpenAI API not configured.";
      }

      const prompt = `Please summarize the following regulatory text concisely while maintaining key points for manufacturers:\n\n${text}`;

      const response = await this.openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [{ role: "user", content: prompt }],
      });

      return response.choices[0].message.content || "Summary unavailable";
    } catch (error: any) {
      console.error("Error summarizing text with OpenAI:", error);
      if (error?.status === 429 || error?.code === 'insufficient_quota') {
        return "Summary unavailable - OpenAI quota exceeded.";
      }
      return "Summary unavailable due to processing error.";
    }
  }

  private getFallbackAnalysis(): RegulationAnalysis {
    return {
      summary: "Manual analysis required. Please review the full regulation text for impact assessment.",
      impactLevel: "medium",
      affectedIndustries: ["Manufacturing"],
      preparationSteps: ["Review full regulation text", "Assess organizational impact", "Consult with legal counsel"]
    };
  }
}

export const openaiService = new OpenAIService();
